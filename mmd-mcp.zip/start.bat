@echo off
cd /d "%~dp0"
where python >nul 2>&1
if not errorlevel 1 (
  python -u server.py --http
  goto :eof
)
where py >nul 2>&1
if not errorlevel 1 (
  py -3 -u server.py --http
  goto :eof
)
echo Python 3.10 or newer is needed and was not found on PATH.
echo Install it from https://www.python.org/downloads/ and tick "Add python.exe to PATH".
pause
