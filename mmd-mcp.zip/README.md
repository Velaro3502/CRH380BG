# MMD MCP

给 `MikuMikuDance_CHS.exe` / `MikuMikuDance_CHT.exe` 用的本地 MCP，监听 `http://127.0.0.1:9877/mcp`。Blender MCP 继续占用 `9876`。

MMDBridge 的 Python（`mmdbridge`）只在导出 AVI 时逐帧执行，没有加载模型或动作的函数。这个服务用窗口消息完成这些操作：把文件拖进主窗口，以及调用固定的菜单命令号。不需要截图识屏，也不需要模拟鼠标去点资源管理器。

只在 Windows 上跑（用的是 Win32 窗口消息），Python 3.10 以上。

## 启动

双击 `start.bat`，或：

```bat
python -u server.py --http
```

健康检查：`http://127.0.0.1:9877/health`

MMD 的安装目录默认是 `G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64`，换机器用环境变量 `MMD_ROOT` 指过去：

```bat
set MMD_ROOT=D:\MMDBridge_v1.3.0\MikuMikuDance_v932x64
python -u server.py --http
```

端口也可以改：`set MMD_MCP_PORT=9888`。没有 ffmpeg 的话，屏幕录像方式会落成 PNG 序列；装了 ffmpeg 就自动合成 mp4。

## 接到 Cursor

`%USERPROFILE%\.cursor\mcp.json`：

```json
{
  "mcpServers": {
    "mmd": {
      "url": "http://127.0.0.1:9877/mcp"
    }
  }
}
```

先启动 `start.bat`，再让 Cursor 重新加载 MCP。不想常驻端口时，可以改成由 Cursor 拉起：

```json
{
  "mcpServers": {
    "mmd": {
      "command": "python",
      "args": ["G:\\MMDBridge_v1.3.0\\mmd-mcp\\server.py", "--stdio"]
    }
  }
}
```

## 工具

| 工具 | 作用 |
| --- | --- |
| `mmd_launch` / `mmd_status` | 启动或查看 CHS、CHT、Console、原版 |
| `mmd_import_model` | 拖入 `.pmx` / `.pmd` |
| `mmd_import_motion` | 拖入 `.vmd`（当前模型；摄像机动作会作用在摄像机上） |
| `mmd_import_pose` / `mmd_import_audio` / `mmd_import_accessory` | `.vpd`、`.wav`、`.x` |
| `mmd_open_project` / `mmd_save_project` | `.pmm` |
| `mmd_set_frame` | 把时间轴拨到指定帧。会短暂把 MMD 置顶并点一次 Go |
| `mmd_export_video` | 默认逐帧截窗口。装了 ffmpeg 就合成 mp4，否则写成 PNG 序列。`method=avi` 走 MMD 自己的导出 AVI，会填好录像尺寸和帧范围，也是触发 MMDBridge 逐帧脚本的方式 |
| `mmd_export_image` / `mmd_export_motion` | 当前画面、当前动作 |
| `mmd_set_resolution` | 「分辨率设定」里的宽高，也就是导出画面的上限 |
| `mmd_screenshot` | 窗口 PNG，返回路径 |
| `mmd_menu` / `mmd_invoke` | 读菜单，或按命令名执行 |
| `mmd_configure_bridge` | 写 `mmdbridge_settings\*.ini`。已经开着的 MMD 要重启才生效 |
| `mmd_bridge_scene` | 读导出过程中 `mmd_mcp_observe.py` 写下的场景 JSON |

`edition` 为 `chs`、`cht`、`console` 或 `original`。只开着一个窗口时可以不填。

几个不在表里但常用的参数：

| 工具 | 参数 | 说明 |
| --- | --- | --- |
| `mmd_export_video` | `method` | `screen`（默认，逐帧截窗口）和 `avi`（走 MMD 自己的导出 AVI，也是触发逐帧脚本的方式） |
| | `width` / `height` | 画面尺寸。实际是去改「分辨率设定」，MMD 按显示分辨率渲染 |
| | `start_frame` / `end_frame` | 帧范围。不填就读 `mmdbridge_settings` 里的 `StartFrame`/`EndFrame` |
| | `overwrite` | 默认 `false`，目标文件已存在就报错；传 `true` 才会删掉重写 |
| | `transcode` | 默认 `true`，有 ffmpeg 的话顺手转成 mp4。没有 ffmpeg 就只留 AVI |
| | `timeout` | 导出等待秒数，默认 600 |
| `mmd_list_files` | `kind` | `model` / `motion` / `pose` / `project` / `audio` / `accessory` / `image`，不给就列全部 |
| | `directory` | 默认是 MMD 的 `UserFile` 目录 |
| `mmd_controls` | `class_name` / `text_contains` | 按控件类名或文字过滤，用来定位帧号框、按钮 |
| `mmd_invoke` | `name` / `command_id` / `menu_path` | 三选一。`name` 用命令名（`export_avi`、`resolution` 等），`menu_path` 是菜单文字路径 |
| | `file_path` | 会弹保存对话框的命令要带上它，路径才会被写进去 |
| `mmd_set_control_text` | `press_enter` | 写完顺手敲一个回车 |
| `mmd_dismiss_dialogs` | `choice` | `ok` / `cancel` / `yes` / `no` / `save` / `discard`，用来回答卡住的对话框 |
| `mmd_close` | `on_prompt` | MMD 退出提示只有「确定」和「取消」两个按钮：确定=退出且不保存，取消=留下窗口。所以 `cancel` 留下窗口，`discard` 和 `save` 都会直接退出，要保留改动请先 `mmd_save_project` |
| `mmd_set_control_text` | `hwnd` / `control_id` | 二选一，指定要写哪个控件，两个都不给会报 `需要 hwnd 或 control_id`。`press_enter` 写完顺手敲回车 |
| `mmd_export_video` | `fps` | 帧率，默认 30 |

协议层面：JSON 语法错、未知方法（`不支持的方法: xxx`）、未知工具（`没有这个工具: xxx`）、`params` 或 `arguments` 不是对象，都返回标准的 JSON-RPC error（`{"jsonrpc":"2.0","id":...,"error":{...}}`），服务不会崩也不会挂。请求体上限 4 MB，超了返回 413（`request body too large`）。

观察脚本在 `MikuMikuDance_v932x64\mmdbridge_scripts\mmd_mcp_observe.py`。要在导出时记下模型和摄像机，把 ScriptName 设成这个文件名，并把 `script_call` 设为 `1`。只想导出视频、不跑 Python 时，把 `script_call` 设为 `0`。

MMDBridge 的 Python 只在导出 AVI 的过程中逐帧执行，没有“导入模型”的接口，所以导入用的是拖放消息。

导出走的是 MMD 的两个对话框。第一个是 Vista 文件框，MMD 把文件名放在 ComboBox 里：`SetWindowText` 打在它内部的 Edit 上会被丢掉，打在 ComboBox 上才有效，所以现在先写 ComboBox 再读回 Edit 核对，不行就退回逐字符 `WM_CHAR`。第二个是「AVI导出设定」，录像尺寸、帧率、导出帧范围这些框同样只吃 `WM_CHAR`。它的默认宽高是 1×1、帧范围是空的，不填就只会导出 1 帧 1 像素。`method=avi` 会按 `width`/`height`（默认 800×600）和 `start_frame`~`end_frame`（不填就读 ini 里的 `StartFrame`/`EndFrame`）把它填好，并且先把「分辨率设定」改成同样大小——MMD 是按显示分辨率渲染的，显示分辨率只有 1×1 的话导出框里写多大都没用。`mmd_export_image` 走的是同一个文件框，因此也能正常写文件名了。

帧号框（控件 554）是个被 MMD 改写过的控件：`SetWindowText` 会被它丢掉，`GetWindowText` 又读不出别的进程的编辑框文字。改帧号只能逐字符发 `WM_CHAR`，而且发之前必须先把光标位置定死——退格只往回删，光标停在哪就只删到哪，所以旧数字会留下来，新的数字还会被插到前面（第 48 帧曾经变成 480）。现在的做法是先 `EM_SETSEL` 全选再退格清空，写完用 `WM_GETTEXT` 读回来核对，不一致就重来。`mmd_set_frame` 在点 Go 之后还会再读一次，确认 MMD 真的停在了目标帧，被截断时会返回 `ok:false` 和实际的 `actual_frame`。

MMD 的退出提示是自绘对话框，只有「确定」和「取消」两个按钮：确定=退出且不保存，取消=留下窗口。所以 `mmd_close` 的 `cancel` 会留在原地，`discard` 和 `save` 都会直接退出；要保留改动请先 `mmd_save_project`。

## 逐帧烘焙 VMD

MMDBridge 的 Python 只在导出 AVI 的过程中逐帧执行，所以「导出一段 AVI」实际是烘焙 VMD 的手段，AVI 本身只是载体。要烘焙就用 `mmdbridge_vmd_mode1.py`：

1. `mmd_configure_bridge` 把 `script_name` 设成 `mmdbridge_vmd_mode1.py`、`script_call` 设成 `1`，`start_frame`/`end_frame` 设成要烘焙的帧范围；
2. **重启 MMD**，ini 只在启动时读；
3. `mmd_import_model` 载入模型、`mmd_import_motion` 载入动作；
4. `mmd_export_video` 用 `method=avi`，`width=1`/`height=1` 保持 1×1 画面省空间，帧范围不填就自动用 ini 里的范围。

产物是 `out\` 下和模型同名的 `.vmd`（例如 `娜娜莉1.0.vmd`），写完还会弹一个 MMDBridge 的提示框。

三个坑：

- **MMD 会把动作的关键帧整体后移，偏移量等于导入时所在的帧。** 在第 0 帧导入，动作末帧就是它自己的末帧；在第 3 帧导入，所有关键帧后移 3 帧，末帧也跟着 +3。所以「动作本身到第几帧」和「烘焙范围要设到第几帧」不是一回事，算错了就会切掉尾巴。
  `mmd_import_motion` 的返回值里直接给了答案：`imported_at_frame`（导入时的帧）、`last_keyframe`（动作文件自己的末帧）、`end_frame`（两者相加后的真实末帧）。`mmd_status` 里也有这份 `motion` 信息。导出范围没覆盖到 `end_frame` 时，`mmd_export_video` 会在 `warnings` 里告诉你会切掉多少帧。
- **导出范围必须和 ini 里的烘焙范围一致。** MMDBridge 的脚本只在渲染到 ini 的 `EndFrame` 时收尾合并，范围对不上就只会留下逐帧的临时数据、没有成品 `.vmd`。`mmd_export_video` 会在 `warnings` 里提示这种不一致。
- **AVI 的画面尺寸由「分辨率设定」决定，导出对话框里的录像尺寸框会被忽略。** 所以 `width`/`height` 实际是去改显示分辨率，`1×1` 就是 MMD 的默认状态。

导出过程中 MMD 会把自己的主窗口藏起来（离屏渲染），烘焙结束时 MMDBridge 还会弹一个「VMD export ended」的消息框把它堵住——那个框不点掉，AVI 就一直停在「帧写完但没有索引和 RIFF 头」的状态。MMD 的窗口重新显示，就是导出真正结束、AVI 已经收尾的信号。`mmd_export_video` 按这个信号判断完成，并且会等 `out\` 里的烘焙产物停止增长再返回，把它们列在 `baked_files` 里。

## 常见报错

工具返回 `ok:false` 或 `isError:true` 时，`error` 字段里是原因。最常撞到的：

| 报错 | 原因和做法 |
| --- | --- |
| `MMD 没有在运行。请先 mmd_launch。` | 没找到 MMD 窗口。先 `mmd_launch`；同一句也出现在 `MMD_ROOT` 指错目录、或者 MMD 启动后立刻崩了的时候 |
| `开着多个 MMD（chs, cht）。请用 edition 指定 chs、cht、console 或 original。` | 同时开了好几个版本。所有工具都能带 `edition` 来指明是哪一个 |
| `找不到 xxx.exe` | `MMD_ROOT` 指的目录里没有这个版本 |
| `xxx.exe 已启动，但 30s 内没有出现主窗口` | MMD 启动失败，或者被安全软件拦了，自己看一眼 MMD 窗口 |
| `MMD 的帧号上限是 99999。` | 帧号框只吃五位数字 |
| `帧号框写入失败，期望 '48'，实际 '4'。` | 帧号框没吃进输入。导出过程中 MMD 窗口是隐藏的，这时候改帧号容易失败，等导出结束再试 |
| `有对话框开着。先 mmd_dismiss_dialogs 再设帧。` | MMD 前面留了个对话框（常见于导出途中弹的提示）。先 `mmd_dismiss_dialogs` |
| `xxx 是一个目录，不是文件路径。` | 导出路径给成了目录 |
| `无法创建目录 ...` / `无法覆盖 ...` | 目录建不出来（盘符不存在、没权限），或者目标文件正被别的程序占用（比如被播放器开着） |
| `已经存在 xxx.avi。overwrite=true 才会覆盖。` | `mmd_export_video` 默认不覆盖已有文件，要覆盖就传 `overwrite: true` |
| `屏幕录像的 end_frame 需要在 0 到 300 之间。` | 屏幕录像有帧数上限，长片用 `method=avi` |
| `等待 AVI 写完超时。文件可能仍在写入。` | 导出超过了 `timeout`（默认 600 秒）。文件可能还在写，等会儿再看，或者把 timeout 调大 |
| `跳到第 N 帧失败：...` | 导出时逐帧定位失败，通常是上面某条的原因（对话框没关、窗口在变） |
| `没能把当前帧设到导出终点。` | 导出开始前要把时间轴移到终点帧，失败了。原因同上一条 |
| `没能设置导出分辨率。` | 「分辨率设定」没设成，多半是 MMD 处于异常状态 |
| `录像过程中窗口尺寸变了。` | 屏幕录像时 MMD 窗口被拖动或改了大小 |
| `没有出现分辨率设定窗口。` / `分辨率窗口里没有宽和高两个输入框。` / `主窗口没有菜单。` | MMD 处于异常状态（可能被模态框挡住），关掉重开 |
| `GlobalAlloc 失败。` / `投递文件失败...` / `PostMessage 命令 ... 失败` | Win32 层面的失败，通常是 MMD 正忙或者已经被关掉了，重试一次 |
| `截取窗口失败。` / `读取画面像素失败。` / `窗口尺寸无效。` | 截屏时 MMD 窗口不可读，重来一次；一直失败就检查 MMD 有没有被最小化 |
| `model 需要这些扩展名: .pmx, .pmd` | 导入的文件类型不对 |
| `文件不存在: ...` | 路径写错了，或者文件所在的盘没插好 |
| `未知版本 ...` / `未知的 kind ...` / `未知命令名 ...` | 参数值不在允许范围，报错里会列出可选值 |
| `参数 xxx 需要是整数，收到 'abc'。` | 传了非数字 |
| `内部错误 xxx: ...` | 没预料到的异常，详细信息在 `mmd-mcp.log` 里 |

两个不是报错、但容易误判的现象：

- **导出过程中 MMD 的主窗口是隐藏的**（离屏渲染），这时 `mmd_status` 里 `visible` 是 `false`，窗口重新显示就说明导出真的结束了。
- **`mmd_set_control_text` 写不进 MMD 自己的编辑框**（帧号框、设置框都只吃逐字符输入），它返回的 `applied` 会是 `false`。改帧号请用 `mmd_set_frame`。

## 已知限制

- 只支持 Windows：整套控制走的是 Win32 窗口消息。
- 帧号上限 99999，这是 MMD 帧号框自己的位数限制。
- 屏幕录像（`method=screen`）的 `end_frame` 最大 300，要更长的片子请用 `method=avi`。
- AVI 导出用的是「未压缩」编码，体积很大：320×240 十一帧就 3.4 MB，4778 帧 640×480 是 5.9 GB。烘焙 VMD 时用 `width=1`/`height=1` 就只占几百 KB。
- 没装 ffmpeg 时屏幕录像会落成 PNG 序列（每帧一张 PNG，装在 `shots/` 旁边的同名文件夹里）。
- 导出范围必须和 `mmdbridge_settings` 里的烘焙范围一致，否则 MMDBridge 不会收尾合并。
- MMD 会把导入的动作按当前帧整体后移，烘焙范围要按后移后的末帧来算（`mmd_import_motion` 会把算好的 `end_frame` 报给你）。
- `mmd_configure_bridge` 改的 ini 要重启 MMD 才生效。
- MMD 的对话框文字读回来是 UTF-8；控制台代码页不是 UTF-8 时（比如中文 Windows 的 936）会显示成乱码，数据本身没问题。

## 自测

服务起来之后可以跑一遍自检，脚本在 `tests\`：

```bat
python tests\test_protocol_and_tools.py   :: 协议层和工具层的边界情况
python tests\test_stdio.py                 :: stdio 传输通道
python tests\test_editions.py              :: 四个语言版本，以及 MMD 没开的情况
python tests\test_readme_covers_errors.py  :: README 有没有漏掉某条报错
```

前两个只需要服务在跑；`test_editions.py` 会关掉正在开的 MMD 再依次拉起 CHS、CHT、原版和 Console，跑完会留下一个空的 CHS 窗口。最后一个不需要服务，它扫代码里所有会返回给用户的消息，逐条核对 README 里有没有对应说明——改了报错文案或者改了 README 都该跑一下。
