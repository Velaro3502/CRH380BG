"""MCP server for MikuMikuDance.

Listens on 127.0.0.1:9877 (Blender MCP keeps 9876) and also speaks stdio when
started with --stdio. Cursor connects with either::

    {"url": "http://127.0.0.1:9877/mcp"}

or::

    {"command": "python", "args": ["G:\\\\MMDBridge_v1.3.0\\\\mmd-mcp\\\\server.py", "--stdio"]}

The HTTP process is the long-running port. Start it with start.bat.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from mmd_control import COMMANDS, FILE_EXT, MmdError, MmdController

HOST = "127.0.0.1"
PORT = int(os.environ.get("MMD_MCP_PORT", "9877"))
MAX_BODY = 4 * 1024 * 1024
HERE = Path(__file__).resolve().parent
LOG_PATH = HERE / "mmd-mcp.log"
CONTROLLER = MmdController()
INSTRUCTIONS = (
    "本机 MikuMikuDance 控制端口，类比 Blender MCP 的 127.0.0.1:9876，这里是 127.0.0.1:9877。"
    "MMDBridge 的 Python 只在导出 AVI 的过程中逐帧运行，不能用来加载模型，所以导入走窗口消息和文件拖放，不要用 Computer Use。"
    "edition 用 chs（简体 MikuMikuDance_CHS.exe）或 cht（繁体 MikuMikuDance_CHT.exe）。"
    "顺序一般是 mmd_launch → mmd_import_model → mmd_import_motion → mmd_set_frame → mmd_export_video。"
    "导出范围是 0 到当前帧。mmd_screenshot 返回 PNG 路径，需要看画面时再读那个文件。"
    "mmd_configure_bridge 改的是 ini，已经开着的 MMD 要重启才读得到。"
)


def log(message: str) -> None:
    try:
        if LOG_PATH.exists() and LOG_PATH.stat().st_size > 2_000_000:
            LOG_PATH.replace(LOG_PATH.with_suffix(".log.1"))
        with LOG_PATH.open("a", encoding="utf-8") as handle:
            handle.write(message.rstrip() + "\n")
    except OSError:
        pass


def dumps(payload: dict) -> str:
    return json.dumps(payload, ensure_ascii=False)


def tool_result(payload: dict, is_error: bool = False) -> dict:
    if "ok" not in payload:
        payload = {"ok": not is_error, **payload}
    return {
        "content": [{"type": "text", "text": dumps(payload)}],
        "isError": is_error or payload.get("ok") is False,
    }


def _edition(args: dict) -> str | None:
    value = args.get("edition")
    return value or None


def _path(args: dict, key: str = "path") -> str:
    value = args.get(key)
    if not value or not isinstance(value, str):
        raise MmdError(f"缺少路径参数 {key}。")
    return value


def _int(args: dict, key: str, default: int | None = None, required: bool = False) -> int | None:
    value = args.get(key)
    if value is None:
        if required:
            raise MmdError(f"缺少参数 {key}。")
        return default
    try:
        return int(value)
    except (TypeError, ValueError):
        raise MmdError(f"参数 {key} 需要是整数，收到 {value!r}。") from None


def _float(args: dict, key: str, default: float | None = None) -> float | None:
    value = args.get(key)
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        raise MmdError(f"参数 {key} 需要是数字，收到 {value!r}。") from None


def t_status(_args: dict) -> dict:
    return CONTROLLER.status()


def t_launch(args: dict) -> dict:
    return CONTROLLER.launch(args.get("edition") or "chs", _float(args, "timeout", 30.0))


def t_close(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    return CONTROLLER.close(inst["hwnd"], inst["pid"], args.get("on_prompt") or "cancel")


def t_menu(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    return {"ok": True, "edition": inst["edition"], "menu": CONTROLLER.menu_tree(inst["hwnd"])}


def t_controls(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    rows = CONTROLLER.children(inst["hwnd"])
    if args.get("class_name"):
        rows = [row for row in rows if row["class"].lower() == str(args["class_name"]).lower()]
    if args.get("text_contains"):
        needle = str(args["text_contains"]).lower()
        rows = [row for row in rows if needle in row["text"].lower()]
    return {"ok": True, "edition": inst["edition"], "count": len(rows), "controls": rows[: _int(args, "limit", 80)]}


def t_import(kind: str, default_choice: str = "yes"):
    def run(args: dict) -> dict:
        choice = args.get("dialog") or default_choice
        return CONTROLLER.import_path(_edition(args), _path(args), kind, choice)

    return run


def t_open_project(args: dict) -> dict:
    return CONTROLLER.menu_action(
        _edition(args),
        "open_project",
        file_path=_path(args),
        message_choice=args.get("on_prompt") or "discard",
        auto_ok=False,
        timeout=20,
    )


def t_save_project(args: dict) -> dict:
    return CONTROLLER.menu_action(_edition(args), "save_as", file_path=_path(args), message_choice="yes", timeout=20)


def t_new_project(args: dict) -> dict:
    return CONTROLLER.menu_action(
        _edition(args),
        "new",
        message_choice=args.get("on_prompt") or "discard",
        auto_ok=False,
        timeout=12,
    )


def t_set_frame(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    frame = _int(args, "frame", required=True)
    result = CONTROLLER.set_frame(inst["hwnd"], frame)
    result["edition"] = inst["edition"]
    return result


def t_set_control_text(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    target = _int(args, "hwnd")
    control_id = _int(args, "control_id")
    if target is None and control_id is not None:
        matches = [row for row in CONTROLLER.children(inst["hwnd"]) if row["id"] == control_id]
        if len(matches) != 1:
            raise MmdError(f"control_id={control_id} 匹配到 {len(matches)} 个控件。")
        target = matches[0]["hwnd"]
    if not target:
        raise MmdError("需要 hwnd 或 control_id。")
    result = CONTROLLER.set_control_text(target, str(args.get("text", "")), bool(args.get("press_enter")))
    return {"ok": result["applied"], "hwnd": target, **result}


def t_export_image(args: dict) -> dict:
    result = CONTROLLER.menu_action(_edition(args), "export_image", file_path=_path(args), message_choice="yes", timeout=25)
    destination = Path(_path(args))
    result["exists"] = destination.is_file()
    result["bytes"] = destination.stat().st_size if destination.is_file() else 0
    result["ok"] = result["exists"] and result["bytes"] > 0
    return result


def t_export_video(args: dict) -> dict:
    method = args.get("method") or "screen"
    if method == "screen":
        end_frame = _int(args, "end_frame", required=True)
        return CONTROLLER.export_screen(_edition(args), _path(args), end_frame, _int(args, "fps", 30))
    return CONTROLLER.export_video(
        _edition(args),
        _path(args),
        end_frame=_int(args, "end_frame"),
        timeout=_float(args, "timeout", 600.0),
        transcode=bool(args.get("transcode", True)),
        overwrite=bool(args.get("overwrite", True)),
        width=_int(args, "width", 800),
        height=_int(args, "height", 600),
        fps=_int(args, "fps"),
        start_frame=_int(args, "start_frame"),
    )


def t_set_resolution(args: dict) -> dict:
    return CONTROLLER.set_resolution(
        _edition(args), _int(args, "width", required=True), _int(args, "height", required=True)
    )


def t_export_motion(args: dict) -> dict:
    return CONTROLLER.menu_action(_edition(args), "export_motion", file_path=_path(args), message_choice="yes", timeout=30)


def t_screenshot(args: dict) -> dict:
    folder = HERE / "shots"
    path = args.get("path") or str(folder / "mmd.png")
    return CONTROLLER.screenshot(_edition(args), path)


def t_invoke(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    command_id = CONTROLLER.command_id(
        args.get("name"), _int(args, "command_id"), args.get("menu_path"), inst["hwnd"]
    )
    if args.get("file_path"):
        log = CONTROLLER.run_with_dialogs(
            inst["hwnd"],
            inst["pid"],
            lambda: CONTROLLER.invoke(inst["hwnd"], command_id),
            file_path=str(Path(args["file_path"]).resolve()),
            message_choice=args.get("dialog") or "yes",
            auto_ok=True,
            timeout=_float(args, "timeout", 20.0),
        )
    else:
        CONTROLLER.invoke(inst["hwnd"], command_id)
        log = []
        if args.get("wait_dialogs", False):
            log = CONTROLLER.run_with_dialogs(
                inst["hwnd"],
                inst["pid"],
                lambda: None,
                message_choice=args.get("dialog") or "ok",
                auto_ok=True,
                timeout=_float(args, "timeout", 3.0),
                settle=0.4,
            )
    return {"ok": True, "command_id": command_id, "dialogs": log, "edition": inst["edition"]}


def t_configure_bridge(args: dict) -> dict:
    return CONTROLLER.configure_bridge(
        edition=args.get("edition") or "chs",
        script_name=args.get("script_name"),
        start_frame=_int(args, "start_frame"),
        end_frame=_int(args, "end_frame"),
        fps=_int(args, "fps"),
        script_call=_int(args, "script_call"),
    )


def t_bridge_scene(_args: dict) -> dict:
    return CONTROLLER.bridge_scene()


def t_list_files(args: dict) -> dict:
    return CONTROLLER.list_files(args.get("directory"), args.get("kind"), _int(args, "limit", 200))


def t_foreground(args: dict) -> dict:
    inst = CONTROLLER.require(_edition(args))
    CONTROLLER.foreground(inst["hwnd"])
    return {"ok": True, **inst}


def t_dismiss(args: dict) -> dict:
    return CONTROLLER.dismiss(_edition(args), args.get("choice") or "ok")


EDITION = {"type": "string", "enum": ["chs", "cht", "console", "original"], "description": "简体 chs、繁体 cht、带控制台 console、日文原版 original。只开着一个窗口时可以不填。"}
PATH = {"type": "string", "description": "绝对路径。"}

TOOLS = [
    ("mmd_status", "查看 MMD 是否在运行、哪个语言版本、最近做过的操作，以及可用菜单命令号。", {"type": "object", "properties": {}}, t_status),
    ("mmd_launch", "启动 MikuMikuDance。已经开着同一版本时直接把窗口拿到前台。", {"type": "object", "properties": {"edition": EDITION, "timeout": {"type": "number"}}, "required": []}, t_launch),
    ("mmd_close", "关闭 MMD。MMD 的退出提示只有 确定/取消 两个按钮：确定=退出且不保存，取消=留下窗口。on_prompt=cancel 留下窗口，discard 退出但不保存，save 同样退出（要保留改动请先调 mmd_save_project）。", {"type": "object", "properties": {"edition": EDITION, "on_prompt": {"type": "string", "enum": ["cancel", "discard", "save"]}}}, t_close),
    ("mmd_foreground", "把 MMD 主窗口放到前台。", {"type": "object", "properties": {"edition": EDITION}}, t_foreground),
    ("mmd_menu", "读出当前语言的完整菜单。命令号在 CHS 和 CHT 上相同。", {"type": "object", "properties": {"edition": EDITION}}, t_menu),
    ("mmd_controls", "列出子控件的类名、文字、id 和位置，用来确认帧号框或按钮。", {"type": "object", "properties": {"edition": EDITION, "class_name": {"type": "string"}, "text_contains": {"type": "string"}, "limit": {"type": "integer"}}}, t_controls),
    ("mmd_import_model", "把 pmx 或 pmd 拖进 MMD 完成加载。dialog 用来回答“是否开启物理”一类提示，默认 yes。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "dialog": {"type": "string", "enum": ["yes", "no", "ok", "cancel"]}}, "required": ["path"]}, t_import("model")),
    ("mmd_import_motion", "把 vmd 拖进 MMD，加到当前模型；摄像机 vmd 会作用在摄像机上。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "dialog": {"type": "string"}}, "required": ["path"]}, t_import("motion")),
    ("mmd_import_pose", "把 vpd 姿势拖进当前模型。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "dialog": {"type": "string"}}, "required": ["path"]}, t_import("pose")),
    ("mmd_import_audio", "把 wav 拖进 MMD。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "dialog": {"type": "string"}}, "required": ["path"]}, t_import("audio")),
    ("mmd_import_accessory", "把 .x 附件拖进 MMD。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "dialog": {"type": "string"}}, "required": ["path"]}, t_import("accessory")),
    ("mmd_open_project", "打开 pmm 工程。on_prompt 处理当前未保存的改动，默认 discard。", {"type": "object", "properties": {"path": PATH, "edition": EDITION, "on_prompt": {"type": "string", "enum": ["discard", "cancel", "save"]}}, "required": ["path"]}, t_open_project),
    ("mmd_save_project", "另存为 pmm。", {"type": "object", "properties": {"path": PATH, "edition": EDITION}, "required": ["path"]}, t_save_project),
    ("mmd_new_project", "新建空白工程。", {"type": "object", "properties": {"edition": EDITION, "on_prompt": {"type": "string", "enum": ["discard", "cancel", "save"]}}}, t_new_project),
    ("mmd_set_frame", "把时间轴当前帧设为 frame。AVI 从 0 导出到这一帧。", {"type": "object", "properties": {"frame": {"type": "integer"}, "edition": EDITION}, "required": ["frame"]}, t_set_frame),
    ("mmd_set_control_text", "按 hwnd 或 control_id 写控件文字。MMD 的帧号框不接受这种写法，会返回 applied=false；改帧号请用 mmd_set_frame。", {"type": "object", "properties": {"hwnd": {"type": "integer"}, "control_id": {"type": "integer"}, "text": {"type": "string"}, "press_enter": {"type": "boolean"}, "edition": EDITION}, "required": ["text"]}, t_set_control_text),
    ("mmd_export_image", "导出当前画面为一张图片。path 用绝对路径，扩展名按 MMD 对话框接受的格式，通常是 bmp。", {"type": "object", "properties": {"path": PATH, "edition": EDITION}, "required": ["path"]}, t_export_image),
    ("mmd_set_resolution", "打开「分辨率设定」，写入宽和高。这是画面输出尺寸。", {"type": "object", "properties": {"width": {"type": "integer"}, "height": {"type": "integer"}, "edition": EDITION}, "required": ["width", "height"]}, t_set_resolution),
    ("mmd_export_video", "导出视频。method=screen（默认）按帧截取 MMD 窗口并用 ffmpeg 合成 mp4，不经过 AVI 对话框；end_frame 最大 300。method=avi 走 MMD 自己的「导出 AVI」：会填好「AVI导出设定」里的录像尺寸（width/height，默认 800x600）、帧率（fps）和导出帧范围（start_frame~end_frame，不填则用 mmdbridge_settings 里配的范围）。", {"type": "object", "properties": {"path": PATH, "end_frame": {"type": "integer"}, "start_frame": {"type": "integer"}, "width": {"type": "integer"}, "height": {"type": "integer"}, "fps": {"type": "integer"}, "method": {"type": "string", "enum": ["screen", "avi"]}, "timeout": {"type": "number"}, "transcode": {"type": "boolean"}, "overwrite": {"type": "boolean"}, "edition": EDITION}, "required": ["path"]}, t_export_video),
    ("mmd_export_motion", "把当前模型的动作导出成 vmd。", {"type": "object", "properties": {"path": PATH, "edition": EDITION}, "required": ["path"]}, t_export_motion),
    ("mmd_screenshot", "截取 MMD 窗口并写成 PNG，返回路径。窗口需要在屏幕上，不要被别的窗口挡住。", {"type": "object", "properties": {"path": {"type": "string"}, "edition": EDITION}}, t_screenshot),
    ("mmd_invoke", "按命令名、命令号或菜单文字执行一项。常用名: " + ", ".join(COMMANDS) + "。会弹出保存对话框时带上 file_path。", {"type": "object", "properties": {"name": {"type": "string"}, "command_id": {"type": "integer"}, "menu_path": {"type": "array", "items": {"type": "string"}}, "file_path": {"type": "string"}, "dialog": {"type": "string"}, "timeout": {"type": "number"}, "edition": EDITION}}, t_invoke),
    ("mmd_dismiss_dialogs", "关掉当前卡住的对话框。choice 为 ok、cancel、yes、no、save、discard。不会擅自填写文件名。", {"type": "object", "properties": {"choice": {"type": "string", "enum": ["ok", "cancel", "yes", "no", "save", "discard"]}, "edition": EDITION}}, t_dismiss),
    ("mmd_configure_bridge", "写入 mmdbridge_settings 里对应 exe 的 ini。script_call=0 关闭导出时的 Python，1 表示导出 AVI 时执行 script_name。已打开的 MMD 要重启。", {"type": "object", "properties": {"edition": EDITION, "script_name": {"type": "string"}, "start_frame": {"type": "integer"}, "end_frame": {"type": "integer"}, "fps": {"type": "integer"}, "script_call": {"type": "integer"}}}, t_configure_bridge),
    ("mmd_bridge_scene", "读取最近一次 AVI 导出时 mmd_mcp_observe.py 写下的场景快照（模型、摄像机、灯光、分辨率）。", {"type": "object", "properties": {}}, t_bridge_scene),
    ("mmd_list_files", "列出目录里的模型、动作、工程或音频。kind 可以是 model、motion、pose、project、audio、accessory、image。默认目录是 MMD 的 UserFile。", {"type": "object", "properties": {"directory": {"type": "string"}, "kind": {"type": "string", "enum": list(FILE_EXT)}, "limit": {"type": "integer"}}}, t_list_files),
]


def dispatch(method: str, params: dict | None, msg_id):
    params = params or {}
    if not isinstance(params, dict):
        raise MmdError("params 必须是对象。")
    if method == "initialize":
        version = (params.get("protocolVersion") or "2025-03-26")
        if version not in {"2024-11-05", "2025-03-26", "2025-06-18"}:
            version = "2025-03-26"
        return {
            "protocolVersion": version,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": "mmd", "version": "1.0.0"},
            "instructions": INSTRUCTIONS,
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {
            "tools": [
                {"name": name, "description": description, "inputSchema": schema}
                for name, description, schema, _fn in TOOLS
            ]
        }
    if method == "tools/call":
        name = params.get("name")
        arguments = params.get("arguments") or {}
        if not isinstance(arguments, dict):
            raise MmdError("arguments 必须是对象。")
        fn = next((item[3] for item in TOOLS if item[0] == name), None)
        if fn is None:
            raise MmdError(f"没有这个工具: {name}")
        try:
            payload = fn(arguments)
            return tool_result(payload)
        except MmdError as exc:
            return tool_result({"ok": False, "error": str(exc)}, True)
        except Exception as exc:
            log(traceback.format_exc())
            return tool_result({"ok": False, "error": f"内部错误 {type(exc).__name__}: {exc}"}, True)
    if method in {"resources/list", "resources/templates/list"}:
        return {"resources": []} if method == "resources/list" else {"resourceTemplates": []}
    if method == "prompts/list":
        return {"prompts": []}
    if method and method.startswith("notifications/"):
        return None
    raise MmdError(f"不支持的方法: {method}")


def handle_message(message: dict) -> dict | None:
    method = message.get("method", "")
    msg_id = message.get("id")
    try:
        result = dispatch(method, message.get("params"), msg_id)
    except MmdError as exc:
        if msg_id is None:
            return None
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32601, "message": str(exc)}}
    except Exception as exc:
        log(traceback.format_exc())
        if msg_id is None:
            return None
        return {"jsonrpc": "2.0", "id": msg_id, "error": {"code": -32603, "message": str(exc)}}
    if msg_id is None or result is None:
        return None
    return {"jsonrpc": "2.0", "id": msg_id, "result": result}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    # Do not let a half open connection hold a worker thread forever.
    timeout = 120

    def log_message(self, fmt: str, *args) -> None:
        log("%s - %s" % (self.address_string(), fmt % args))

    def _session(self) -> str:
        return self.headers.get("Mcp-Session-Id") or "mmd"

    def _send(self, status: int, body: bytes, content_type: str, extra: dict | None = None) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self.send_header("Access-Control-Expose-Headers", "Mcp-Session-Id")
        self.send_header("Mcp-Session-Id", self._session() if self.headers.get("Mcp-Session-Id") else "mmd")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self._send(204, b"", "text/plain")

    def do_GET(self) -> None:  # noqa: N802
        if self.path.split("?", 1)[0] in {"/health", "/"}:
            body = dumps({"ok": True, "service": "mmd-mcp", "port": PORT}).encode("utf-8")
            self._send(200, body, "application/json")
            return
        self._send(405, b"", "text/plain")

    def do_DELETE(self) -> None:  # noqa: N802
        self._send(200, b"", "text/plain")

    def do_POST(self) -> None:  # noqa: N802
        try:
            length = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            length = 0
        if length < 0 or length > MAX_BODY:
            self.close_connection = True
            self._send(413, b'{"error":"request body too large"}', "application/json")
            return
        raw = self.rfile.read(length) if length else b""
        accept = self.headers.get("Accept") or ""
        try:
            message = json.loads(raw.decode("utf-8")) if raw else {}
        except json.JSONDecodeError as exc:
            body = dumps({"jsonrpc": "2.0", "id": None, "error": {"code": -32700, "message": str(exc)}}).encode("utf-8")
            self._send(400, body, "application/json")
            return
        messages = message if isinstance(message, list) else [message]
        responses = [item for item in (handle_message(item) for item in messages) if item is not None]
        if not responses:
            self._send(202, b"", "text/plain")
            return
        use_sse = "text/event-stream" in accept and "application/json" not in accept
        if use_sse:
            chunks = []
            for response in responses:
                data = dumps(response)
                chunks.append(f"event: message\ndata: {data}\n\n")
            self._send(200, "".join(chunks).encode("utf-8"), "text/event-stream")
            return
        body = dumps(responses[0] if len(responses) == 1 else responses).encode("utf-8")
        self._send(200, body, "application/json")


def serve_http(announce: bool = True) -> None:
    ThreadingHTTPServer.allow_reuse_address = True
    try:
        server = ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        log(f"bind {HOST}:{PORT} failed: {exc}")
        if announce:
            print(f"端口 {PORT} 已被占用。如果 MMD MCP 已在运行，直接连接 http://{HOST}:{PORT}/mcp", flush=True)
            raise SystemExit(1)
        return
    log(f"listening http://{HOST}:{PORT}/mcp")
    if announce:
        print(f"MMD MCP  http://{HOST}:{PORT}/mcp", flush=True)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


def _read_stdio() -> dict | None:
    headers = {}
    while True:
        line = sys.stdin.buffer.readline()
        if line == b"":
            return None
        if line in {b"\r\n", b"\n"}:
            break
        key, value = line.decode("ascii", errors="replace").split(":", 1)
        headers[key.strip().lower()] = value.strip()
    length = int(headers.get("content-length", "0"))
    if length <= 0:
        return None
    return json.loads(sys.stdin.buffer.read(length).decode("utf-8"))


def _write_stdio(payload: dict) -> None:
    data = dumps(payload).encode("utf-8")
    sys.stdout.buffer.write(f"Content-Length: {len(data)}\r\n\r\n".encode("ascii"))
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def serve_stdio() -> None:
    log("stdio session")
    while True:
        message = _read_stdio()
        if message is None:
            return
        messages = message if isinstance(message, list) else [message]
        for item in messages:
            response = handle_message(item)
            if response is not None:
                _write_stdio(response)


def main() -> None:
    global HOST, PORT
    parser = argparse.ArgumentParser(description="MMD MCP server")
    parser.add_argument("--stdio", action="store_true", help="speak MCP on stdin/stdout instead of HTTP")
    parser.add_argument("--http", action="store_true", help="serve MCP on 127.0.0.1:9877 (this is the default)")
    parser.add_argument("--host", default=HOST)
    parser.add_argument("--port", type=int, default=PORT)
    args = parser.parse_args()
    if args.stdio:
        serve_stdio()
        return
    HOST = args.host
    PORT = args.port
    serve_http()


if __name__ == "__main__":
    main()
