"""Win32 controller for MikuMikuDance 9.32 (MMDBridge).

MMDBridge's embedded Python can read the scene only while an AVI export is
running. Loading a model, a motion, or a project is a main-window operation,
so this module drives the CHS / CHT / original executables directly:

* WM_DROPFILES loads pmx/pmd/vmd/vpd/wav/x/pmm without a file dialog
* stable menu command ids (same across the localized exes) trigger export
* dialogs that those commands open are filled in by control id, not by clicking
  coordinates
"""

from __future__ import annotations

import ctypes
import json
import os
import re
import struct
import subprocess
import threading
import time
import uuid
import zlib
from ctypes import wintypes
from pathlib import Path

ROOT = Path(os.environ.get("MMD_ROOT", r"G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64"))
EXES = {
    "chs": "MikuMikuDance_CHS.exe",
    "cht": "MikuMikuDance_CHT.exe",
    "console": "MikuMikuDance_Console.exe",
    "original": "MikuMikuDance.exe",
}
WINDOW_CLASS = "Polygon Movie Maker"

# Command ids read from the live 9.32 menu. Localization only rewrites the
# caption (see mmdbridge_settings/*.ini); the ids stay the same.
COMMANDS = {
    "new": 204,
    "open_project": 205,
    "save": 207,
    "save_as": 208,
    "export_avi": 223,
    "export_image": 276,
    "import_pose": 202,
    "export_pose": 203,
    "import_motion": 209,
    "export_motion": 210,
    "import_wav": 206,
    "exit": 200,
    "resolution": 212,
    "select_all_bones": 217,
    "physics_toggle": 269,
    "physics_on": 265,
    "physics_follow_bone": 270,
    "physics_off": 272,
    "gravity": 266,
    "bridge_settings": 100,
    "bridge_about": 101,
    "english_mode": 260,
}

FILE_EXT = {
    "model": (".pmx", ".pmd"),
    "motion": (".vmd",),
    "pose": (".vpd",),
    "project": (".pmm",),
    "audio": (".wav",),
    "accessory": (".x",),
    "image": (".bmp", ".png", ".jpg", ".jpeg", ".tga"),
}

WM_COMMAND = 0x0111
WM_CLOSE = 0x0010
WM_DROPFILES = 0x0233
WM_SETTEXT = 0x000C
WM_GETTEXT = 0x000D
WM_KEYDOWN = 0x0100
WM_KEYUP = 0x0101
WM_CHAR = 0x0102
EM_SETSEL = 0x00B1
VK_RETURN = 0x0D
VK_BACK = 0x08
VK_END = 0x23
MAX_FRAME = 99999
SW_RESTORE = 9
SRCCOPY = 0x00CC0020
SMTO_ABORTIFHUNG = 0x0002
GMEM_MOVEABLE = 0x0002
GMEM_ZEROINIT = 0x0040
GMEM_DDESHARE = 0x2000
MIIM_STATE = 0x0001
MIIM_ID = 0x0002
MIIM_SUBMENU = 0x0004
MIIM_FTYPE = 0x0100
MIIM_STRING = 0x0040
MFT_SEPARATOR = 0x0800
MFS_CHECKED = 0x0008
PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
CDM_SETCONTROLTEXT = 0x0400 + 100 + 4
FILE_NAME_CONTROL = 1148

CHOICE_IDS = {
    "ok": (1,),
    "cancel": (2,),
    "yes": (6, 1),
    "save": (6, 1),
    "no": (7,),
    # MMD's exit prompt only has 确定 (1) and 取消 (2), where 确定 exits without
    # saving, so the id 7 of a 是/否/取消 box has to fall back to id 1.
    "discard": (7, 1),
}
CHOICE_TEXT = {
    "ok": ("确定", "确认", "ok", "是"),
    "cancel": ("取消", "cancel"),
    "yes": ("是", "yes", "确定", "保存"),
    "save": ("保存", "是", "yes"),
    "no": ("否", "no", "不保存"),
    "discard": ("不保存", "否", "no"),
}


class MmdError(RuntimeError):
    pass


def vmd_last_frame(path: Path) -> int | None:
    """The last keyframe of a VMD's bones and morphs.

    MMD shifts every keyframe by the frame the motion was imported on, so the
    frame the motion really ends on is this number plus that offset.
    """
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if not data.startswith(b"Vocaloid Motion Data"):
        return None
    pos = 50 if b"0002" in data[:30] else 30
    if pos + 4 > len(data):
        return None
    bones = struct.unpack("<I", data[pos:pos + 4])[0]
    pos += 4
    if pos + bones * 111 > len(data):
        return None
    last = 0
    for _ in range(bones):
        last = max(last, struct.unpack("<I", data[pos + 15:pos + 19])[0])
        pos += 111
    if pos + 4 <= len(data):
        morphs = struct.unpack("<I", data[pos:pos + 4])[0]
        pos += 4
        if pos + morphs * 23 <= len(data):
            for _ in range(morphs):
                last = max(last, struct.unpack("<I", data[pos + 15:pos + 19])[0])
                pos += 23
    return last or None


def _norm_label(text: str) -> str:
    text = re.sub(r"\(&.\)", "", text or "")
    return text.replace("&", "").replace(" ", "").strip().lower()


class DROPFILES(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ("pFiles", wintypes.DWORD),
        ("x", wintypes.LONG),
        ("y", wintypes.LONG),
        ("fNC", wintypes.BOOL),
        ("fWide", wintypes.BOOL),
    ]


class MENUITEMINFOW(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.UINT),
        ("fMask", wintypes.UINT),
        ("fType", wintypes.UINT),
        ("fState", wintypes.UINT),
        ("wID", wintypes.UINT),
        ("hSubMenu", wintypes.HMENU),
        ("hbmpChecked", wintypes.HBITMAP),
        ("hbmpUnchecked", wintypes.HBITMAP),
        ("dwItemData", ctypes.c_ulonglong),
        ("dwTypeData", wintypes.LPWSTR),
        ("cch", wintypes.UINT),
        ("hbmpItem", wintypes.HBITMAP),
    ]


class GUID(ctypes.Structure):
    _fields_ = [
        ("Data1", ctypes.c_uint32),
        ("Data2", ctypes.c_uint16),
        ("Data3", ctypes.c_uint16),
        ("Data4", ctypes.c_ubyte * 8),
    ]


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [
        ("GdiplusVersion", ctypes.c_uint32),
        ("DebugEventCallback", ctypes.c_void_p),
        ("SuppressBackgroundThread", ctypes.c_int),
        ("SuppressExternalCodecs", ctypes.c_int),
    ]


def _guid(value: str) -> GUID:
    import uuid

    parsed = uuid.UUID(value)
    guide = GUID()
    guide.Data1 = parsed.time_low
    guide.Data2 = parsed.time_mid
    guide.Data3 = parsed.time_hi_version
    clock = parsed.clock_seq
    raw = bytes([(clock >> 8) & 0xFF, clock & 0xFF]) + parsed.node.to_bytes(6, "big")
    guide.Data4 = (ctypes.c_ubyte * 8).from_buffer_copy(raw)
    return guide


PNG_CLSID = _guid("557CF406-1A04-11D3-9A73-0000F81EF32E")


def _win(name: str) -> ctypes.WinDLL:
    return ctypes.WinDLL(name, use_last_error=True)


def _enable_dpi() -> None:
    try:
        ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)
    except Exception:
        try:
            ctypes.WinDLL("user32").SetProcessDPIAware()
        except Exception:
            pass


_enable_dpi()


class MmdController:
    def __init__(self, root: Path = ROOT) -> None:
        self.root = Path(root)
        self.user32 = _win("user32")
        self.kernel32 = _win("kernel32")
        self.shell32 = _win("shell32")
        self.gdi32 = _win("gdi32")
        self._bind()
        self._lock = threading.RLock()
        self.history: list[dict] = []
        self._gdi_token = None
        # Where the last imported motion really ends, including the frame it
        # was imported on.
        self._motion: dict | None = None

    def _bind(self) -> None:
        u, k = self.user32, self.kernel32
        u.EnumWindows.argtypes = [ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM), wintypes.LPARAM]
        u.EnumChildWindows.argtypes = [wintypes.HWND, ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM), wintypes.LPARAM]
        u.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        u.GetClassNameW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        u.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        u.IsWindowVisible.argtypes = [wintypes.HWND]
        u.IsWindowVisible.restype = wintypes.BOOL
        u.IsWindowEnabled.argtypes = [wintypes.HWND]
        u.IsWindowEnabled.restype = wintypes.BOOL
        u.IsWindow.argtypes = [wintypes.HWND]
        u.IsIconic.argtypes = [wintypes.HWND]
        u.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        u.SetForegroundWindow.argtypes = [wintypes.HWND]
        u.GetForegroundWindow.restype = wintypes.HWND
        u.AttachThreadInput.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.BOOL]
        u.BringWindowToTop.argtypes = [wintypes.HWND]
        u.SystemParametersInfoW.argtypes = [wintypes.UINT, wintypes.UINT, ctypes.POINTER(wintypes.RECT), wintypes.UINT]
        u.SystemParametersInfoW.restype = wintypes.BOOL
        u.SetWindowPos.argtypes = [
            wintypes.HWND,
            wintypes.HWND,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.UINT,
        ]
        u.GetParent.argtypes = [wintypes.HWND]
        u.GetParent.restype = wintypes.HWND
        u.ScreenToClient.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
        u.ScreenToClient.restype = wintypes.BOOL
        u.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        u.GetCursorPos.argtypes = [ctypes.POINTER(wintypes.POINT)]
        u.GetCursorPos.restype = wintypes.BOOL
        u.mouse_event.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, wintypes.DWORD, ctypes.c_size_t]
        u.GetMenu.argtypes = [wintypes.HWND]
        u.GetMenu.restype = wintypes.HMENU
        u.GetMenuItemCount.argtypes = [wintypes.HMENU]
        u.GetMenuItemCount.restype = ctypes.c_int
        u.GetMenuItemInfoW.argtypes = [wintypes.HMENU, wintypes.UINT, wintypes.BOOL, ctypes.POINTER(MENUITEMINFOW)]
        u.GetMenuItemInfoW.restype = wintypes.BOOL
        u.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.PostMessageW.restype = wintypes.BOOL
        u.SendMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
        u.SendMessageW.restype = ctypes.c_ssize_t
        u.SendMessageTimeoutW.argtypes = [
            wintypes.HWND,
            wintypes.UINT,
            wintypes.WPARAM,
            wintypes.LPARAM,
            wintypes.UINT,
            wintypes.UINT,
            ctypes.POINTER(ctypes.c_size_t),
        ]
        u.SendMessageTimeoutW.restype = ctypes.c_size_t
        u.GetDlgItem.argtypes = [wintypes.HWND, ctypes.c_int]
        u.GetDlgItem.restype = wintypes.HWND
        u.GetDlgCtrlID.argtypes = [wintypes.HWND]
        u.GetDlgCtrlID.restype = ctypes.c_int
        u.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
        u.FindWindowExW.restype = wintypes.HWND
        u.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        u.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        u.GetDC.argtypes = [wintypes.HWND]
        u.GetDC.restype = ctypes.c_void_p
        u.ReleaseDC.argtypes = [wintypes.HWND, ctypes.c_void_p]
        g = self.gdi32
        g.CreateCompatibleDC.argtypes = [ctypes.c_void_p]
        g.CreateCompatibleDC.restype = ctypes.c_void_p
        g.CreateCompatibleBitmap.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
        g.CreateCompatibleBitmap.restype = ctypes.c_void_p
        g.SelectObject.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
        g.SelectObject.restype = ctypes.c_void_p
        g.DeleteObject.argtypes = [ctypes.c_void_p]
        g.DeleteDC.argtypes = [ctypes.c_void_p]
        g.BitBlt.argtypes = [
            ctypes.c_void_p,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_int,
            ctypes.c_void_p,
            ctypes.c_int,
            ctypes.c_int,
            wintypes.DWORD,
        ]
        u.IsHungAppWindow.argtypes = [wintypes.HWND]
        u.IsHungAppWindow.restype = wintypes.BOOL
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.OpenProcess.restype = wintypes.HANDLE
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.QueryFullProcessImageNameW.argtypes = [
            wintypes.HANDLE,
            wintypes.DWORD,
            wintypes.LPWSTR,
            ctypes.POINTER(wintypes.DWORD),
        ]
        k.QueryFullProcessImageNameW.restype = wintypes.BOOL
        k.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        k.GlobalAlloc.restype = ctypes.c_void_p
        k.GlobalLock.argtypes = [ctypes.c_void_p]
        k.GlobalLock.restype = ctypes.c_void_p
        k.GlobalUnlock.argtypes = [ctypes.c_void_p]
        k.GlobalFree.argtypes = [ctypes.c_void_p]
        self.shell32.DragAcceptFiles.argtypes = [wintypes.HWND, wintypes.BOOL]

    # ---------------------------------------------------------------- process
    def exe(self, edition: str) -> Path:
        try:
            name = EXES[edition]
        except KeyError as exc:
            raise MmdError(f"未知版本 {edition!r}，可选: {', '.join(EXES)}") from exc
        path = self.root / name
        if not path.is_file():
            raise MmdError(f"找不到 {path}")
        return path

    def _ensure_dir(self, directory: Path) -> None:
        """Create a directory, reporting the reason when that is not possible."""
        try:
            directory.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise MmdError(f"无法创建目录 {directory}：{exc.strerror or exc}") from None

    def _check_target(self, path: Path) -> None:
        """Reject a target that cannot be a file, before MMD opens a dialog.

        Saving onto a directory makes MMD pop a nested confirm box on top of
        the file dialog, and a dialog with a modal box on top cannot be
        clicked any more.
        """
        if path.exists() and path.is_dir():
            raise MmdError(f"{path} 是一个目录，不是文件路径。")

    def _with_suffix(self, path: Path, suffix: str) -> Path:
        try:
            return path.with_suffix(suffix)
        except ValueError as exc:
            raise MmdError(f"路径 {path} 不合法：{exc}") from None

    def _pid_exe(self, pid: int) -> str:
        handle = self.kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid)
        if not handle:
            return ""
        try:
            size = wintypes.DWORD(1024)
            buf = ctypes.create_unicode_buffer(1024)
            if not self.kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
                return ""
            return buf.value
        finally:
            self.kernel32.CloseHandle(handle)

    def _enum_top(self) -> list[int]:
        found: list[int] = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def callback(hwnd, _lp):
            found.append(int(hwnd))
            return True

        self.user32.EnumWindows(callback, 0)
        return found

    def _class_name(self, hwnd: int) -> str:
        buf = ctypes.create_unicode_buffer(256)
        self.user32.GetClassNameW(hwnd, buf, 256)
        return buf.value

    def _window_text(self, hwnd: int) -> str:
        length = int(self.user32.GetWindowTextLengthW(hwnd) or 0)
        buf = ctypes.create_unicode_buffer(max(2, length + 1))
        self.user32.GetWindowTextW(hwnd, buf, len(buf))
        return buf.value

    def _pid_of(self, hwnd: int) -> int:
        pid = wintypes.DWORD()
        self.user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)

    def instances(self) -> list[dict]:
        rows = []
        for hwnd in self._enum_top():
            if self._class_name(hwnd) != WINDOW_CLASS:
                continue
            if not self.user32.IsWindow(hwnd):
                continue
            if not self.user32.GetMenu(hwnd):
                continue
            pid = self._pid_of(hwnd)
            exe = self._pid_exe(pid)
            edition = next((key for key, name in EXES.items() if exe.lower().endswith(name.lower())), "unknown")
            rows.append(
                {
                    "hwnd": hwnd,
                    "pid": pid,
                    "edition": edition,
                    "exe": exe,
                    "title": self._window_text(hwnd),
                    "enabled": bool(self.user32.IsWindowEnabled(hwnd)),
                    # MMD hides its own window while it renders the export.
                    "visible": bool(self.user32.IsWindowVisible(hwnd)),
                }
            )
        return rows

    def require(self, edition: str | None = None) -> dict:
        rows = self.instances()
        if edition:
            rows = [row for row in rows if row["edition"] == edition]
        if not rows:
            raise MmdError("MMD 没有在运行。请先 mmd_launch。")
        if len(rows) > 1 and not edition:
            names = ", ".join(row["edition"] for row in rows)
            raise MmdError(f"开着多个 MMD（{names}）。请用 edition 指定 chs、cht、console 或 original。")
        return rows[0]

    def launch(self, edition: str = "chs", timeout: float = 30.0) -> dict:
        with self._lock:
            existing = [row for row in self.instances() if row["edition"] == edition]
            if existing:
                self.foreground(existing[0]["hwnd"])
                return {"ok": True, "already_running": True, **existing[0]}
            exe = self.exe(edition)
            subprocess.Popen([str(exe)], cwd=str(self.root))
            deadline = time.time() + timeout
            while time.time() < deadline:
                time.sleep(0.25)
                found = [row for row in self.instances() if row["edition"] == edition]
                if found:
                    self.foreground(found[0]["hwnd"])
                    self._note("launch", {"edition": edition, "pid": found[0]["pid"]})
                    return {"ok": True, "already_running": False, **found[0]}
            raise MmdError(f"{exe.name} 已启动，但 {timeout:.0f}s 内没有出现主窗口。")

    def arrange(self, hwnd: int) -> None:
        """Keep the main window inside the work area so MMD lays out the 3D view."""
        if self.user32.IsIconic(hwnd):
            self.user32.ShowWindow(hwnd, SW_RESTORE)
        work = wintypes.RECT()
        self.user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(work), 0)
        rect = wintypes.RECT()
        self.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        width = int(rect.right - rect.left)
        height = int(rect.bottom - rect.top)
        work_width = max(800, int(work.right - work.left))
        work_height = max(600, int(work.bottom - work.top))
        spills = rect.left < work.left or rect.top < work.top or rect.right > work.right or rect.bottom > work.bottom
        if spills or width > work_width or height > work_height:
            self.user32.SetWindowPos(hwnd, 0, int(work.left) + 40, int(work.top) + 40, min(1500, work_width - 80), min(980, work_height - 80), 0x0004)

    def foreground(self, hwnd: int) -> None:
        if self._class_name(hwnd) == WINDOW_CLASS:
            self.arrange(hwnd)
        current = int(self.user32.GetForegroundWindow() or 0)
        current_thread = self.user32.GetWindowThreadProcessId(current, None) if current else 0
        target_thread = self.user32.GetWindowThreadProcessId(hwnd, None)
        if current_thread and current_thread != target_thread:
            self.user32.AttachThreadInput(current_thread, target_thread, True)
            self.user32.SetForegroundWindow(hwnd)
            self.user32.AttachThreadInput(current_thread, target_thread, False)
        else:
            self.user32.SetForegroundWindow(hwnd)
        self.user32.BringWindowToTop(hwnd)

    # ------------------------------------------------------------------ menus
    def _menu_item(self, menu: int, index: int) -> dict | None:
        info = MENUITEMINFOW()
        info.cbSize = ctypes.sizeof(MENUITEMINFOW)
        info.fMask = MIIM_STRING | MIIM_ID | MIIM_SUBMENU | MIIM_FTYPE | MIIM_STATE
        buf = ctypes.create_unicode_buffer(1024)
        info.dwTypeData = ctypes.cast(buf, wintypes.LPWSTR)
        info.cch = 1024
        if not self.user32.GetMenuItemInfoW(menu, index, True, ctypes.byref(info)):
            return None
        submenu = int(info.hSubMenu or 0)
        separator = bool(info.fType & MFT_SEPARATOR)
        command_id = None if submenu or separator else int(info.wID)
        return {
            "index": index,
            "text": "" if separator else buf.value,
            "separator": separator,
            "command_id": command_id,
            "checked": bool(info.fState & MFS_CHECKED),
            "submenu": submenu,
        }

    def menu_tree(self, hwnd: int) -> list[dict]:
        menu = int(self.user32.GetMenu(hwnd) or 0)
        if not menu:
            raise MmdError("主窗口没有菜单。")

        def walk(handle: int) -> list[dict]:
            count = int(self.user32.GetMenuItemCount(handle))
            items = []
            for index in range(max(0, count)):
                item = self._menu_item(handle, index)
                if item is None:
                    continue
                children = walk(item.pop("submenu")) if item.get("submenu") else []
                if children:
                    item["children"] = children
                items.append(item)
            return items

        return walk(menu)

    def invoke(self, hwnd: int, command_id: int) -> None:
        if not self.user32.PostMessageW(hwnd, WM_COMMAND, int(command_id), 0):
            raise MmdError(f"PostMessage 命令 {command_id} 失败，错误 {ctypes.get_last_error()}。")

    def command_id(self, name: str | None, command_id: int | None, menu_path: list[str] | None, hwnd: int) -> int:
        if command_id:
            return int(command_id)
        if name:
            try:
                return COMMANDS[name]
            except KeyError as exc:
                raise MmdError(f"未知命令名 {name!r}。可用: {', '.join(COMMANDS)}") from exc
        if menu_path:
            node: list[dict] | dict = self.menu_tree(hwnd)
            for part in menu_path:
                items = node if isinstance(node, list) else node.get("children", [])
                want = _norm_label(part)
                found = [item for item in items if want and want in _norm_label(item.get("text", ""))]
                if len(found) != 1:
                    labels = [item.get("text", "") for item in items if item.get("text")]
                    raise MmdError(f"菜单 {part!r} 匹配到 {len(found)} 项。这一层有: {labels}")
                node = found[0]
            if isinstance(node, list) or not node.get("command_id"):
                raise MmdError("这个菜单项还会展开，没有可以直接执行的命令。")
            return int(node["command_id"])
        raise MmdError("需要 name、command_id 或 menu_path 其中之一。")

    # ------------------------------------------------------------------ files
    def drop_file(self, hwnd: int, path: str) -> None:
        target = Path(path)
        if not target.is_file():
            raise MmdError(f"文件不存在: {target}")
        self.shell32.DragAcceptFiles(hwnd, True)
        rect = wintypes.RECT()
        self.user32.GetClientRect(hwnd, ctypes.byref(rect))
        header = DROPFILES()
        header.pFiles = ctypes.sizeof(DROPFILES)
        header.x = max(1, (rect.right - rect.left) // 2)
        header.y = max(1, (rect.bottom - rect.top) // 2)
        header.fNC = False
        header.fWide = True
        payload = (str(target.resolve()) + "\0\0").encode("utf-16le")
        total = ctypes.sizeof(DROPFILES) + len(payload)
        memory = self.kernel32.GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT | GMEM_DDESHARE, total)
        if not memory:
            raise MmdError("GlobalAlloc 失败。")
        locked = self.kernel32.GlobalLock(memory)
        try:
            ctypes.memmove(locked, ctypes.addressof(header), ctypes.sizeof(header))
            ctypes.memmove(locked + ctypes.sizeof(header), payload, len(payload))
        finally:
            self.kernel32.GlobalUnlock(memory)
        if not self.user32.PostMessageW(hwnd, WM_DROPFILES, memory, 0):
            self.kernel32.GlobalFree(memory)
            raise MmdError(f"投递文件失败，错误 {ctypes.get_last_error()}。")

    def _send(self, hwnd: int, message: int, wparam: int, lparam: int, timeout_ms: int = 2000) -> int:
        result = ctypes.c_size_t()
        self.user32.SendMessageTimeoutW(hwnd, message, wparam, lparam, SMTO_ABORTIFHUNG, timeout_ms, ctypes.byref(result))
        return int(result.value)

    def _send_text(self, hwnd: int, message: int, wparam: int, text: str, timeout_ms: int = 2000) -> int:
        # Dedicated prototype so the path stays a UTF-16 pointer for this call only.
        send = self.user32.SendMessageTimeoutW
        previous = tuple(send.argtypes or [])
        send.argtypes = [
            wintypes.HWND,
            wintypes.UINT,
            wintypes.WPARAM,
            wintypes.LPCWSTR,
            wintypes.UINT,
            wintypes.UINT,
            ctypes.POINTER(ctypes.c_size_t),
        ]
        result = ctypes.c_size_t()
        try:
            send(hwnd, message, wparam, text, SMTO_ABORTIFHUNG, timeout_ms, ctypes.byref(result))
        finally:
            send.argtypes = list(previous)
        return int(result.value)

    def set_control_text(self, control: int, text: str, press_enter: bool = False) -> dict:
        self.user32.SetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
        self.user32.SetWindowTextW.restype = wintypes.BOOL
        self.user32.SetWindowTextW(control, text)
        if press_enter:
            self._send(control, WM_KEYDOWN, VK_RETURN, 0)
            self._send(control, WM_KEYUP, VK_RETURN, 0)
        written = self._read_control_text(control)
        applied = written == text
        return {
            "text": written,
            "applied": applied,
            "note": "" if applied else "这个控件没有接受 SetWindowText。帧号框只能靠 WM_CHAR 逐字输入。",
        }

    def children(self, hwnd: int) -> list[dict]:
        found: list[int] = []

        @ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        def callback(child, _lp):
            found.append(int(child))
            return True

        self.user32.EnumChildWindows(hwnd, callback, 0)
        rows = []
        for child in found:
            rect = wintypes.RECT()
            self.user32.GetWindowRect(child, ctypes.byref(rect))
            rows.append(
                {
                    "hwnd": child,
                    "id": int(self.user32.GetDlgCtrlID(child)),
                    "class": self._class_name(child),
                    "text": self._window_text(child),
                    "visible": bool(self.user32.IsWindowVisible(child)),
                    "rect": [int(rect.left), int(rect.top), int(rect.right), int(rect.bottom)],
                }
            )
        return rows

    def _frame_edit(self, hwnd: int) -> tuple[dict | None, dict | None, str]:
        """Find the frame number box and the Go button next to it.

        Returns (edit, go, reason). The reason is empty when both were found.
        """
        controls = self.children(hwnd)
        go_labels = {"go", "前往", "跳转"}
        buttons = [
            child
            for child in controls
            if child["class"] == "Button" and child["visible"] and _norm_label(child["text"]) in go_labels
        ]
        if not buttons:
            return None, None, "没有找到时间轴上的 Go 按钮。"
        go = min(buttons, key=lambda child: child["rect"][0])
        left, top, right, bottom = go["rect"]
        button_mid = (top + bottom) / 2
        edits = []
        for child in controls:
            if child["class"] != "Edit" or not child["visible"]:
                continue
            edit_left, edit_top, edit_right, edit_bottom = child["rect"]
            edit_mid = (edit_top + edit_bottom) / 2
            gap = left - edit_right
            if abs(edit_mid - button_mid) <= 24 and 0 <= gap <= 160:
                edits.append((gap, child))
        if edits:
            return min(edits)[1], go, ""
        # After a resize, GetWindowRect on this edit can come back nonsense.
        # On 9.32 the box immediately left of Go is control 554, one below Go's 553.
        sibling = [child for child in controls if child["class"] == "Edit" and child["id"] in {go["id"] - 1, 554}]
        if not sibling:
            return None, go, "Go 按钮左边没有帧号输入框。"
        return sibling[0], go, ""

    def _current_frame(self, hwnd: int) -> int:
        """Read the frame number box. Returns 0 when it cannot be read."""
        edit, _go, _reason = self._frame_edit(hwnd)
        if edit is None:
            return 0
        try:
            return int(self._read_control_text(edit["hwnd"]).strip())
        except ValueError:
            return 0

    def set_frame(self, hwnd: int, frame: int) -> dict:
        if frame < 0:
            raise MmdError("帧号不能是负数。")
        if frame > MAX_FRAME:
            raise MmdError(f"MMD 的帧号上限是 {MAX_FRAME}。")
        edit, go, reason = self._frame_edit(hwnd)
        if edit is None:
            return {"ok": False, "reason": reason, "go": go}
        if self.dialogs(self._pid_of(hwnd)):
            return {"ok": False, "reason": "有对话框开着。先 mmd_dismiss_dialogs 再设帧。"}
        self._place_frame_edit(hwnd, edit, go["rect"])
        self._type_into_edit(edit["hwnd"], str(int(frame)))
        self._click_widget(go["hwnd"], hwnd)
        time.sleep(0.05)
        actual = self._read_control_text(edit["hwnd"])
        result = {"ok": True, "frame": int(frame), "edit_id": edit["id"], "go_id": go["id"]}
        if actual and actual != str(int(frame)):
            # MMD clamps the jump to the end of the loaded motion.
            result["ok"] = False
            result["actual_frame"] = actual
            result["reason"] = f"MMD 停在第 {actual} 帧，不是第 {frame} 帧。"
        return result

    def _place_frame_edit(self, parent: int, edit: dict, go_rect: list[int]) -> None:
        """MMD leaves this edit at a 2x2 off-screen spot after the main window is resized."""
        left, top, right, bottom = edit["rect"]
        width = right - left
        height = bottom - top
        # Only the freshly resized window leaves this edit as a 2x2 off-screen stub.
        # Once it has a real size, GetWindowRect can disagree with where MMD paints it;
        # moving it again shoves the box onto another panel.
        if width >= 20 and height >= 16 and top > -100 and left > -100:
            return
        go_left, go_top, go_right, go_bottom = go_rect
        width = 80
        height = max(22, go_bottom - go_top)
        point = wintypes.POINT(go_left - width - 4, go_top)
        owner = int(self.user32.GetParent(edit["hwnd"]) or parent)
        self.user32.ScreenToClient(owner, ctypes.byref(point))
        self.user32.SetWindowPos(edit["hwnd"], 0, int(point.x), int(point.y), width, height, 0x0004 | 0x0040)
        edit["rect"] = [go_left - width - 4, go_top, go_left - 4, go_top + height]

    def _read_control_text(self, control: int) -> str:
        """Read an edit control that lives in another process.

        GetWindowTextW comes back empty for foreign edit controls, so the text
        has to be pulled with WM_GETTEXT.
        """
        buffer = ctypes.create_unicode_buffer(512)
        address = ctypes.cast(buffer, ctypes.c_void_p).value
        self._send(control, WM_GETTEXT, 64, address)
        return buffer.value

    def _clear_edit(self, edit: int) -> bool:
        """Empty the frame box no matter where the caret happens to sit."""
        for attempt in range(3):
            # Select everything, then one backspace drops the selection.
            self._send(edit, EM_SETSEL, 0, -1)
            self._send(edit, WM_CHAR, VK_BACK, 0)
            if not self._read_control_text(edit):
                return True
            # Fall back to walking the caret to the end and backspacing.
            self._send(edit, WM_KEYDOWN, VK_END, 0)
            self._send(edit, WM_KEYUP, VK_END, 0)
            for _ in range(12):
                self._send(edit, WM_CHAR, VK_BACK, 0)
            if not self._read_control_text(edit):
                return True
        return False

    def _type_into_edit(self, edit: int, text: str) -> str:
        # SetWindowText updates a buffer MMD does not paint or read.
        # WM_CHAR goes through the subclass that actually owns the frame number.
        # Backspace alone is not enough: it only deletes backwards from the
        # caret, and the caret is wherever the previous edit left it, so the
        # old digits would survive and the new ones would land in front of
        # them (frame 48 used to end up as 480).
        written = ""
        for attempt in range(3):
            if not self._clear_edit(edit):
                continue
            for char in text:
                self._send(edit, WM_CHAR, ord(char), 0)
            written = self._read_control_text(edit)
            if written == text:
                return written
        raise MmdError(f"帧号框写入失败，期望 {text!r}，实际 {written!r}。输入框可能不接受这么多位数字。")


    def _click_widget(self, widget: int, owner: int) -> None:
        rect = wintypes.RECT()
        self.user32.GetWindowRect(widget, ctypes.byref(rect))
        previous = wintypes.POINT()
        self.user32.GetCursorPos(ctypes.byref(previous))
        try:
            self.user32.SetWindowPos(owner, wintypes.HWND(-1), 0, 0, 0, 0, 0x0001 | 0x0002)
            time.sleep(0.05)
            self.user32.SetCursorPos((int(rect.left) + int(rect.right)) // 2, (int(rect.top) + int(rect.bottom)) // 2)
            time.sleep(0.05)
            self.user32.mouse_event(0x0002, 0, 0, 0, 0)
            time.sleep(0.04)
            self.user32.mouse_event(0x0004, 0, 0, 0, 0)
            time.sleep(0.05)
        finally:
            self.user32.SetCursorPos(int(previous.x), int(previous.y))
            self.user32.SetWindowPos(owner, wintypes.HWND(-2), 0, 0, 0, 0, 0x0001 | 0x0002)

    # ---------------------------------------------------------------- dialogs
    def dialogs(self, pid: int) -> list[int]:
        rows = []
        for hwnd in self._enum_top():
            if self._pid_of(hwnd) != pid or not self.user32.IsWindowVisible(hwnd):
                continue
            if self._class_name(hwnd) == "#32770":
                rows.append(hwnd)
        return rows

    def _dialog_buttons(self, hwnd: int) -> list[dict]:
        buttons = []
        for child in self.children(hwnd):
            if child["class"] == "Button":
                buttons.append(child)
        return buttons

    def _filename_edit(self, hwnd: int) -> int:
        classic = int(self.user32.GetDlgItem(hwnd, FILE_NAME_CONTROL) or 0)
        if classic:
            inner = int(self.user32.FindWindowExW(classic, None, "Edit", None) or 0)
            return inner or classic
        edits = [child for child in self.children(hwnd) if child["class"] == "Edit" and child["visible"]]
        if not edits:
            return 0
        # Vista file dialogs keep the file name in the wide edit above 保存 / 打开.
        return max(edits, key=lambda child: (child["rect"][2] - child["rect"][0], child["rect"][1]))["hwnd"]

    def _is_file_dialog(self, hwnd: int) -> bool:
        if self.user32.GetDlgItem(hwnd, FILE_NAME_CONTROL):
            return True
        labels = " ".join(_norm_label(button["text"]) for button in self._dialog_buttons(hwnd))
        if any(token in labels for token in ("保存", "打开", "save", "open")) and self._filename_edit(hwnd):
            return True
        return False

    def _fill_file_dialog(self, hwnd: int, path: str) -> None:
        edit = self._filename_edit(hwnd)
        if edit:
            self._write_file_name(edit, path)
        self._click_choice(hwnd, "save")

    def _write_file_name(self, edit: int, path: str) -> bool:
        """Put the target path into a file dialog's file name box.

        SetWindowText on the edit inside a Vista file dialog is ignored, but the
        combo that hosts it does take the text and copies it down to the edit.
        Typing the path with WM_CHAR works as well and is the fallback.
        """
        self.user32.SetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPCWSTR]
        self.user32.SetWindowTextW.restype = wintypes.BOOL
        combo = int(self.user32.GetParent(edit) or 0)
        for target in ([combo, edit] if combo else [edit]):
            if not target:
                continue
            self.user32.SetWindowTextW(target, path)
            if self._read_control_text(edit) == path:
                return True
        self._send(edit, EM_SETSEL, 0, -1)
        self._send(edit, WM_CHAR, VK_BACK, 0)
        for char in path:
            self._send(edit, WM_CHAR, ord(char), 0)
        return self._read_control_text(edit) == path

    def _click_choice(self, hwnd: int, choice: str) -> str:
        buttons = self._dialog_buttons(hwnd)
        wanted_ids = CHOICE_IDS.get(choice, CHOICE_IDS["ok"])
        for cid in wanted_ids:
            for button in buttons:
                if button["id"] == cid:
                    self._press_button(button["hwnd"], hwnd, cid)
                    return f"id:{cid}:{button['text']}"
        tokens = tuple(token.lower() for token in CHOICE_TEXT.get(choice, ()))
        for button in buttons:
            label = _norm_label(button["text"])
            if any(token in label for token in tokens):
                self._press_button(button["hwnd"], hwnd, button["id"] or 1)
                return f"text:{button['text']}"
        if buttons:
            button = buttons[0]
            self._press_button(button["hwnd"], hwnd, button["id"] or 1)
            return f"first:{button['text']}"
        self.user32.PostMessageW(hwnd, WM_COMMAND, 1, 0)
        return "id:1"

    def _press_button(self, button: int, owner: int, command_id: int) -> None:
        # MMD's Vista file dialog ignores BM_CLICK. A client-area button message does get through.
        # SendMessageTimeout, not SendMessage: a dialog that sits behind another modal
        # box never processes the message and a blocking send would hang the server.
        rect = wintypes.RECT()
        self.user32.GetClientRect(button, ctypes.byref(rect))
        x = max(1, int(rect.right - rect.left) // 2)
        y = max(1, int(rect.bottom - rect.top) // 2)
        point = (y << 16) | (x & 0xFFFF)
        self._send(button, 0x0201, 1, point)
        self._send(button, 0x0202, 0, point)
        self.user32.PostMessageW(owner, WM_COMMAND, int(command_id), button)

    def _describe_dialog(self, hwnd: int) -> dict:
        statics = [child["text"] for child in self.children(hwnd) if child["class"] == "Static" and child["text"]]
        buttons = [child["text"] for child in self._dialog_buttons(hwnd)]
        return {
            "hwnd": hwnd,
            "title": self._window_text(hwnd),
            "file_dialog": self._is_file_dialog(hwnd),
            "statics": statics[:8],
            "buttons": buttons[:8],
        }

    def run_with_dialogs(
        self,
        hwnd: int,
        pid: int,
        trigger,
        *,
        file_path: str | None = None,
        message_choice: str = "yes",
        auto_ok: bool = True,
        timeout: float = 20.0,
        settle: float = 0.8,
        on_dialog=None,
    ) -> list[dict]:
        """Run trigger(), then answer the dialogs MMD opens.

        File dialogs receive file_path. Message boxes receive message_choice.
        Further dialogs (the VFW codec picker, MMDBridge's message boxes) get
        OK when auto_ok is set. on_dialog(dialog) can fill in a dialog before
        it is answered; returning True marks it as handled. The wait ends once
        the UI has been quiet.
        """
        log: list[dict] = []
        file_done = file_path is None
        filled = file_path is None
        fills = 0
        handled: dict[int, float] = {}
        started = time.time()
        last_busy = started
        trigger()
        while time.time() - started < timeout:
            dialogs = [dlg for dlg in self.dialogs(pid) if self.user32.IsWindow(dlg)]
            file_open = False
            # Answer plain message boxes before the file dialog: a file dialog
            # with a nested prompt on top of it cannot be clicked at all.
            for dlg in sorted(dialogs, key=lambda handle: 1 if self._is_file_dialog(handle) else 0):
                if self._is_file_dialog(dlg):
                    file_open = True
                if dlg in handled and time.time() - handled[dlg] < 1.6:
                    continue
                info = self._describe_dialog(dlg)
                if info["file_dialog"] and file_path and fills < 2:
                    # A full path once. If the Vista dialog navigates to the folder and
                    # clears the box, the second try writes only the file name.
                    text = file_path if fills == 0 else Path(file_path).name
                    self.foreground(dlg)
                    edit = self._filename_edit(dlg)
                    written = self._write_file_name(edit, text) if edit else False
                    info["action"] = self._click_choice(dlg, "save") + ":" + text
                    info["filename_written"] = written
                    fills += 1
                    filled = True
                elif info["file_dialog"]:
                    info["action"] = "file-waiting"
                elif on_dialog is not None and on_dialog(dlg):
                    info["action"] = "settings-filled"
                elif not auto_ok:
                    # The caller asked for specific answers only, e.g. the
                    # unsaved changes prompt when closing MMD.
                    info["action"] = self._click_choice(dlg, message_choice)
                elif file_done:
                    info["action"] = self._click_choice(dlg, "ok")
                else:
                    info["action"] = self._click_choice(dlg, message_choice)
                handled[dlg] = time.time()
                log.append(info)
                last_busy = time.time()
            if filled and file_path and not file_open:
                file_done = True
            if dialogs:
                last_busy = time.time()
            quiet = time.time() - last_busy > settle
            if file_done and quiet and time.time() - started > 0.3:
                break
            time.sleep(0.12)
        if file_path and not file_done:
            log.append({"action": "file-dialog-not-closed", "path": file_path})
        return log

    def close(self, hwnd: int, pid: int, on_prompt: str = "cancel") -> dict:
        if on_prompt not in {"cancel", "discard", "save"}:
            raise MmdError("on_prompt 只能是 cancel、discard 或 save。")
        log = self.run_with_dialogs(
            hwnd,
            pid,
            lambda: self.user32.PostMessageW(hwnd, WM_CLOSE, 0, 0),
            message_choice=on_prompt,
            auto_ok=False,
            timeout=8,
            settle=0.6,
        )
        alive = any(row["hwnd"] == hwnd for row in self.instances())
        return {"ok": not alive, "still_open": alive, "dialogs": log}

    # --------------------------------------------------------------- commands
    def import_path(self, edition: str | None, path: str, kind: str, message_choice: str = "yes") -> dict:
        target = Path(path)
        if target.suffix.lower() not in FILE_EXT[kind]:
            allowed = ", ".join(FILE_EXT[kind])
            raise MmdError(f"{kind} 需要这些扩展名: {allowed}")
        with self._lock:
            inst = self.require(edition)
            self.foreground(inst["hwnd"])
            # MMD shifts a motion by the frame it is imported on, so remember
            # that frame to tell later where the motion really ends.
            imported_at = self._current_frame(inst["hwnd"]) if kind == "motion" else None
            log = self.run_with_dialogs(
                inst["hwnd"],
                inst["pid"],
                lambda: self.drop_file(inst["hwnd"], str(target)),
                message_choice=message_choice,
                auto_ok=True,
                timeout=12,
                settle=2.0,
            )
            self._note(f"import_{kind}", {"path": str(target), "edition": inst["edition"]})
            result = {"ok": True, "edition": inst["edition"], "path": str(target.resolve()), "dialogs": log}
            if kind == "motion":
                last = vmd_last_frame(target)
                if last is not None:
                    end = int(imported_at or 0) + last
                    self._motion = {
                        "path": str(target),
                        "imported_at_frame": int(imported_at or 0),
                        "last_keyframe": last,
                        "end_frame": end,
                    }
                    result.update(self._motion)
                    result["note"] = (
                        f"动作在第 {imported_at} 帧导入，MMD 把所有关键帧后移了 {imported_at} 帧，"
                        f"实际末帧是 {end}。烘焙或导出的帧范围要覆盖到它。"
                    )
            return result

    def menu_action(
        self,
        edition: str | None,
        name: str,
        *,
        file_path: str | None = None,
        message_choice: str = "yes",
        auto_ok: bool = True,
        timeout: float = 20.0,
    ) -> dict:
        with self._lock:
            inst = self.require(edition)
            self.foreground(inst["hwnd"])
            if file_path:
                self._ensure_dir(Path(file_path).parent)
                self._check_target(Path(file_path))
            log = self.run_with_dialogs(
                inst["hwnd"],
                inst["pid"],
                lambda: self.invoke(inst["hwnd"], COMMANDS[name]),
                file_path=str(Path(file_path).resolve()) if file_path else None,
                message_choice=message_choice,
                auto_ok=auto_ok,
                timeout=timeout,
            )
            return {"ok": True, "edition": inst["edition"], "command": name, "dialogs": log, **inst}

    def capture_bgr(self, hwnd: int) -> tuple[int, int, bytes]:
        rect = wintypes.RECT()
        self.user32.GetWindowRect(hwnd, ctypes.byref(rect))
        width = int(rect.right - rect.left)
        height = int(rect.bottom - rect.top)
        if width <= 0 or height <= 0:
            raise MmdError("窗口尺寸无效。")
        screen = self.user32.GetDC(0)
        memory = self.gdi32.CreateCompatibleDC(screen)
        bitmap = self.gdi32.CreateCompatibleBitmap(screen, width, height)
        previous = self.gdi32.SelectObject(memory, bitmap)
        try:
            if not self.gdi32.BitBlt(memory, 0, 0, width, height, screen, rect.left, rect.top, SRCCOPY):
                raise MmdError("截取窗口失败。")
            raw = self._dib_bits(memory, bitmap, width, height)
        finally:
            self.gdi32.SelectObject(memory, previous)
            self.gdi32.DeleteObject(bitmap)
            self.gdi32.DeleteDC(memory)
            self.user32.ReleaseDC(0, screen)
        bgr = bytearray(width * height * 3)
        for index in range(width * height):
            src = index * 4
            dst = index * 3
            bgr[dst] = raw[src]
            bgr[dst + 1] = raw[src + 1]
            bgr[dst + 2] = raw[src + 2]
        return width, height, bytes(bgr)

    def _dib_bits(self, hdc: int, bitmap: int, width: int, height: int) -> bytes:
        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ("biSize", wintypes.DWORD),
                ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD),
            ]

        header = BITMAPINFOHEADER()
        header.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        header.biWidth = width
        header.biHeight = -height
        header.biPlanes = 1
        header.biBitCount = 32
        get_bits = self.gdi32.GetDIBits
        get_bits.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            wintypes.UINT,
            wintypes.UINT,
            ctypes.c_void_p,
            ctypes.c_void_p,
            wintypes.UINT,
        ]
        get_bits.restype = ctypes.c_int
        pixels = ctypes.create_string_buffer(width * height * 4)
        if get_bits(hdc, bitmap, 0, height, pixels, ctypes.byref(header), 0) == 0:
            raise MmdError("读取画面像素失败。")
        return pixels.raw

    def _export_png_sequence(self, edition: str | None, destination: Path, end_frame: int) -> dict:
        folder = self._with_suffix(destination, "")
        self._ensure_dir(folder)
        inst = self.require(edition)
        for dlg in list(self.dialogs(inst["pid"])):
            self._click_choice(dlg, "cancel")
        frames = []
        for frame in range(int(end_frame) + 1):
            inst = self.require(edition)
            moved = self.set_frame(inst["hwnd"], frame)
            if not moved.get("ok"):
                raise MmdError(f"跳到第 {frame} 帧失败：{moved.get('reason', '未知原因')}")
            path = folder / f"frame_{frame:04d}.png"
            shot = self.screenshot(edition, str(path))
            frames.append(shot["path"])
        return {
            "ok": True,
            "frames": frames,
            "count": len(frames),
            "note": "PATH 里没有 ffmpeg，所以输出了 PNG 序列。安装 ffmpeg 后同样的调用会直接得到 mp4。",
        }

    def export_screen(self, edition: str | None, path: str, end_frame: int, fps: int = 30) -> dict:
        if end_frame < 0 or end_frame > 300:
            raise MmdError("屏幕录像的 end_frame 需要在 0 到 300 之间。更长的片子请用 method=avi。")
        destination = Path(path)
        if destination.suffix.lower() != ".mp4":
            destination = self._with_suffix(destination, ".mp4")
        self._ensure_dir(destination.parent)
        self._check_target(destination)
        ffmpeg = self._ffmpeg()
        if not ffmpeg:
            return self._export_png_sequence(edition, destination, end_frame)
        with self._lock:
            inst = self.require(edition)
            for dlg in list(self.dialogs(inst["pid"])):
                self._click_choice(dlg, "cancel")
            self.foreground(inst["hwnd"])
            time.sleep(0.2)
            width, height, _first = self.capture_bgr(inst["hwnd"])
            command = [
                ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "bgr24", "-s", f"{width}x{height}",
                "-r", str(int(fps)), "-i", "-", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(destination),
            ]
            proc = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            try:
                assert proc.stdin is not None
                for frame in range(int(end_frame) + 1):
                    moved = self.set_frame(inst["hwnd"], frame)
                    if not moved.get("ok"):
                        raise MmdError(f"跳到第 {frame} 帧失败：{moved.get('reason', '未知原因')}")
                    time.sleep(0.05)
                    _w, _h, pixels = self.capture_bgr(inst["hwnd"])
                    if (_w, _h) != (width, height):
                        raise MmdError("录像过程中窗口尺寸变了。")
                    proc.stdin.write(pixels)
            finally:
                if proc.stdin:
                    proc.stdin.close()
            _out, err = proc.communicate(timeout=120)
            ok = proc.returncode == 0 and destination.is_file() and destination.stat().st_size > 0
            self._note("export_screen", {"path": str(destination), "frames": int(end_frame) + 1})
            return {
                "ok": ok,
                "mp4": str(destination),
                "bytes": destination.stat().st_size if destination.is_file() else 0,
                "frames": int(end_frame) + 1,
                "width": width,
                "height": height,
                "ffmpeg_error": "" if ok else (err or b"").decode("utf-8", errors="replace")[-600:],
            }

    def _read_resolution(self, hwnd: int, pid: int) -> tuple[str, str]:
        """Open 分辨率设定, read width and height, close it again."""
        self.invoke(hwnd, COMMANDS["resolution"])
        deadline = time.time() + 5
        dialog = 0
        while time.time() < deadline and not dialog:
            for dlg in self.dialogs(pid):
                if "分辨率" in self._window_text(dlg) or self.user32.GetDlgItem(dlg, 621):
                    dialog = dlg
                    break
            time.sleep(0.1)
        if not dialog:
            return ("", "")
        edits = [child for child in self.children(dialog) if child["class"] == "Edit"]
        edits.sort(key=lambda child: child["rect"][0])
        values = tuple(self._read_control_text(child["hwnd"]).strip() for child in edits[:2])
        self._click_choice(dialog, "cancel")
        return values

    def set_resolution(self, edition: str | None, width: int, height: int) -> dict:
        if width < 1 or height < 1 or width > 7680 or height > 4320:
            raise MmdError("分辨率超出可接受范围。")
        with self._lock:
            inst = self.require(edition)
            self.foreground(inst["hwnd"])
            self.invoke(inst["hwnd"], COMMANDS["resolution"])
            deadline = time.time() + 5
            dialog = 0
            while time.time() < deadline:
                for dlg in self.dialogs(inst["pid"]):
                    if "分辨率" in self._window_text(dlg) or self.user32.GetDlgItem(dlg, 621):
                        dialog = dlg
                        break
                if dialog:
                    break
                time.sleep(0.1)
            if not dialog:
                raise MmdError("没有出现分辨率设定窗口。")
            edits = [child for child in self.children(dialog) if child["class"] == "Edit"]
            edits.sort(key=lambda child: child["rect"][0])
            if len(edits) < 2:
                self._click_choice(dialog, "cancel")
                raise MmdError("分辨率窗口里没有宽和高两个输入框。")
            # These edits ignore SetWindowText, so they have to be typed into.
            self._type_into_edit(edits[0]["hwnd"], str(int(width)))
            self._type_into_edit(edits[1]["hwnd"], str(int(height)))
            self._click_choice(dialog, "ok")
            time.sleep(0.3)
            applied = self._read_resolution(inst["hwnd"], inst["pid"])
            wanted = (str(int(width)), str(int(height)))
            return {
                "ok": applied == wanted,
                "width": int(width),
                "height": int(height),
                "applied": list(applied),
                "edition": inst["edition"],
                "reason": "" if applied == wanted else f"MMD 里的分辨率仍是 {applied}。",
            }

    def _fill_avi_settings(
        self, dialog: int, width: int, height: int, fps: int, start: int, end: int
    ) -> bool:
        """Fill MMD's 「AVI导出设定」 dialog.

        It opens after the file name is chosen. Its size fields start at 1x1 and
        its frame range is empty, which would produce a one pixel, one frame
        video unless they are filled in.
        """
        fields = {row["id"]: row["hwnd"] for row in self.children(dialog) if row["class"] == "Edit"}
        if not {609, 610, 611, 612, 613} <= set(fields):
            return False
        for cid, value in ((612, width), (613, height), (611, fps), (609, start), (610, end)):
            # These edits ignore SetWindowText, so they have to be typed into.
            self._type_into_edit(fields[cid], str(int(value)))
        return True

    def _bridge_settings(self, edition: str) -> dict:
        """Read the export range MMDBridge was configured with."""
        ini = self.root / "mmdbridge_settings" / f"{self.exe(edition).name}.ini"
        out = {"start": 0, "end": 0, "fps": 30}
        if not ini.is_file():
            return out
        text = ini.read_text(encoding="utf-8", errors="replace")
        for key, name in (("StartFrame", "start"), ("EndFrame", "end"), ("ExportFPS", "fps")):
            match = re.search(rf"^\s*{key}\s*=\s*(\d+)", text, re.MULTILINE)
            if match:
                out[name] = int(match.group(1))
        return out

    def _out_snapshot(self) -> dict:
        out = self.root / "out"
        snap = {}
        if out.is_dir():
            for path in out.iterdir():
                try:
                    stat = path.stat()
                    snap[path.name] = (stat.st_size, stat.st_mtime)
                except OSError:
                    pass
        return snap

    def _wait_bake(self, before: dict, timeout: float = 300.0, grace: float = 90.0) -> list[dict]:
        """Wait until the files the bake wrote into out/ stop growing.

        MMDBridge finishes writing the baked files after MMD closed the AVI,
        so returning as soon as the video is done would report success while
        the bake is still running. The bake may also take a moment to show up
        at all, so nothing appearing is not treated as "nothing to bake"
        before the grace period is over.
        """
        deadline = time.time() + timeout
        started = time.time()
        changed: list[dict] = []
        last = None
        stable = 0
        while time.time() < deadline:
            current = self._out_snapshot()
            changed = [
                {"name": name, "bytes": value[0]}
                for name, value in current.items()
                if name not in before or before[name] != value
            ]
            if not changed:
                if time.time() - started > grace:
                    return []
            else:
                signature = tuple(sorted((row["name"], row["bytes"]) for row in changed))
                if signature == last:
                    stable += 1
                    if stable >= 4:
                        return changed
                else:
                    stable = 0
                last = signature
            time.sleep(0.5)
        return changed

    def export_video(
        self,
        edition: str | None,
        path: str,
        end_frame: int | None = None,
        timeout: float = 600.0,
        transcode: bool = True,
        overwrite: bool = True,
        width: int = 800,
        height: int = 600,
        fps: int | None = None,
        start_frame: int | None = None,
    ) -> dict:
        destination = Path(path)
        wants_mp4 = destination.suffix.lower() == ".mp4"
        avi = self._with_suffix(destination, ".avi") if wants_mp4 or destination.suffix.lower() != ".avi" else destination
        if avi.exists():
            if not overwrite:
                raise MmdError(f"已经存在 {avi}。overwrite=true 才会覆盖。")
            try:
                avi.unlink()
            except OSError as exc:
                raise MmdError(f"无法覆盖 {avi}：{exc.strerror or exc}") from None
        self._ensure_dir(avi.parent)
        self._check_target(avi)
        with self._lock:
            inst = self.require(edition)
            bridge = self._bridge_settings(inst["edition"])
            first = int(start_frame if start_frame is not None else bridge["start"])
            last = int(end_frame if end_frame is not None else bridge["end"])
            rate = int(fps if fps is not None else bridge["fps"])
            frame_result = None
            if end_frame is not None:
                frame_result = self.set_frame(inst["hwnd"], int(end_frame))
                if not frame_result.get("ok"):
                    return {"ok": False, "reason": "没能把当前帧设到导出终点。", "frame": frame_result}
            self.foreground(inst["hwnd"])
            resolution = None
            if int(width) >= 1 and int(height) >= 1:
                # MMD renders the video at the display resolution. The size
                # fields in the export dialog do not override it, so the
                # display resolution has to be set to the wanted size.
                resolution = self.set_resolution(inst["edition"], int(width), int(height))
                if not resolution.get("ok"):
                    return {"ok": False, "reason": "没能设置导出分辨率。", "resolution": resolution}
            before = self._out_snapshot()
            dialogs = self.run_with_dialogs(
                inst["hwnd"],
                inst["pid"],
                lambda: self.invoke(inst["hwnd"], COMMANDS["export_avi"]),
                file_path=str(avi.resolve()),
                message_choice="yes",
                auto_ok=True,
                timeout=min(40.0, timeout),
                settle=0.5,
                on_dialog=lambda dlg: self._fill_avi_settings(dlg, width, height, rate, first, last),
            )
            deadline = time.time() + timeout
            last_size = -1
            stable = 0
            while time.time() < deadline:
                for dlg in self.dialogs(inst["pid"]):
                    if self._is_file_dialog(dlg):
                        continue
                    info = self._describe_dialog(dlg)
                    info["action"] = self._click_choice(dlg, "ok")
                    dialogs.append(info)
                    stable = 0
                enabled = bool(self.user32.IsWindowEnabled(inst["hwnd"]))
                # MMD hides its window while it renders and shows it again once
                # the export is done, so a visible window means the video is
                # really finished and not just written up to its last frame.
                visible = bool(self.user32.IsWindowVisible(inst["hwnd"]))
                size = avi.stat().st_size if avi.exists() else 0
                if visible and enabled and not self.dialogs(inst["pid"]) and size > 0 and size == last_size:
                    stable += 1
                    if stable >= 6:
                        break
                else:
                    stable = 0
                last_size = size
                time.sleep(0.3)
            else:
                return {
                    "ok": False,
                    "reason": "等待 AVI 写完超时。文件可能仍在写入。",
                    "avi": str(avi),
                    "bytes": avi.stat().st_size if avi.exists() else 0,
                    "dialogs": dialogs,
                    "frame": frame_result,
                }
            baked = self._wait_bake(before)
            warnings = []
            if [first, last] != [bridge["start"], bridge["end"]]:
                warnings.append(
                    f"导出的帧范围 {first}~{last} 和 mmdbridge_settings 里的烘焙范围 "
                    f"{bridge['start']}~{bridge['end']} 不一致。MMDBridge 只在渲染到 ini 的 EndFrame "
                    "时才收尾合并，VMD 不会被输出。"
                )
            if self._motion and last < self._motion["end_frame"]:
                missing = self._motion["end_frame"] - last
                warnings.append(
                    f"动作是在第 {self._motion['imported_at_frame']} 帧导入的，MMD 把关键帧后移了同样多的帧，"
                    f"实际末帧是 {self._motion['end_frame']}。当前范围只到 {last}，"
                    f"最后 {missing} 帧会被切掉。"
                )
            result = {
                "ok": avi.exists() and avi.stat().st_size > 0,
                "avi": str(avi),
                "bytes": avi.stat().st_size if avi.exists() else 0,
                "dialogs": dialogs[-12:],
                "frame": frame_result,
                "edition": inst["edition"],
                "range": [first, last],
                "size": [int(width), int(height)],
                "fps": rate,
                "resolution": resolution,
                "baked_files": baked,
                "warnings": warnings,
            }
            if transcode or wants_mp4:
                mp4 = destination if wants_mp4 else self._with_suffix(avi, ".mp4")
                ffmpeg = self._ffmpeg()
                result["ffmpeg"] = ffmpeg
                if ffmpeg and result["ok"]:
                    proc = subprocess.run(
                        [ffmpeg, "-y", "-i", str(avi), "-c:v", "libx264", "-pix_fmt", "yuv420p", str(mp4)],
                        capture_output=True,
                        text=True,
                        timeout=max(60, timeout),
                    )
                    result["mp4"] = str(mp4)
                    result["transcode_ok"] = proc.returncode == 0 and mp4.exists()
                    if proc.returncode != 0:
                        result["transcode_error"] = (proc.stderr or "")[-800:]
                elif not ffmpeg:
                    result["transcode_ok"] = False
                    result["transcode_error"] = "找不到 ffmpeg，已保留 AVI。"
            self._note("export_video", {"avi": str(avi)})
            return result

    def screenshot(self, edition: str | None, path: str) -> dict:
        destination = Path(path)
        if destination.suffix.lower() != ".png":
            destination = self._with_suffix(destination, ".png")
        self._ensure_dir(destination.parent)
        self._check_target(destination)
        with self._lock:
            inst = self.require(edition)
            self.foreground(inst["hwnd"])
            time.sleep(0.25)
            rect = wintypes.RECT()
            self.user32.GetWindowRect(inst["hwnd"], ctypes.byref(rect))
            width = int(rect.right - rect.left)
            height = int(rect.bottom - rect.top)
            if width <= 0 or height <= 0:
                raise MmdError("窗口尺寸无效。")
            screen = self.user32.GetDC(0)
            memory = self.gdi32.CreateCompatibleDC(screen)
            bitmap = self.gdi32.CreateCompatibleBitmap(screen, width, height)
            previous = self.gdi32.SelectObject(memory, bitmap)
            self.gdi32.BitBlt(memory, 0, 0, width, height, screen, rect.left, rect.top, SRCCOPY)
            try:
                self._save_png(memory, bitmap, width, height, str(destination))
            finally:
                self.gdi32.SelectObject(memory, previous)
                self.gdi32.DeleteObject(bitmap)
                self.gdi32.DeleteDC(memory)
                self.user32.ReleaseDC(0, screen)
            return {"ok": destination.is_file(), "path": str(destination), "width": width, "height": height, "edition": inst["edition"]}

    def _save_png(self, hdc: int, bitmap: int, width: int, height: int, path: str) -> None:
        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ("biSize", wintypes.DWORD),
                ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD),
            ]

        header = BITMAPINFOHEADER()
        header.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        header.biWidth = width
        header.biHeight = -height
        header.biPlanes = 1
        header.biBitCount = 32
        header.biCompression = 0
        get_bits = self.gdi32.GetDIBits
        get_bits.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            wintypes.UINT,
            wintypes.UINT,
            ctypes.c_void_p,
            ctypes.c_void_p,
            wintypes.UINT,
        ]
        get_bits.restype = ctypes.c_int
        pixels = ctypes.create_string_buffer(width * height * 4)
        lines = get_bits(hdc, bitmap, 0, height, pixels, ctypes.byref(header), 0)
        if lines == 0:
            raise MmdError("读取画面像素失败。")
        raw = bytearray()
        source = pixels.raw
        for y in range(height):
            raw.append(0)
            start = y * width * 4
            for x in range(width):
                offset = start + x * 4
                raw.append(source[offset + 2])
                raw.append(source[offset + 1])
                raw.append(source[offset])

        def chunk(tag: bytes, data: bytes) -> bytes:
            return struct.pack(">I", len(data)) + tag + data + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

        png = b"\x89PNG\r\n\x1a\n"
        png += chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
        png += chunk(b"IDAT", zlib.compress(bytes(raw), 6))
        png += chunk(b"IEND", b"")
        Path(path).write_bytes(png)

    def configure_bridge(
        self,
        edition: str = "chs",
        script_name: str | None = None,
        start_frame: int | None = None,
        end_frame: int | None = None,
        fps: int | None = None,
        script_call: int | None = None,
    ) -> dict:
        ini = self.root / "mmdbridge_settings" / f"{self.exe(edition).name}.ini"
        if not ini.is_file():
            raise MmdError(f"找不到 {ini}")
        if script_call is not None and int(script_call) not in (0, 1):
            raise MmdError("script_call 只能是 0 或 1。")
        if start_frame is not None and int(start_frame) < 0:
            raise MmdError("start_frame 不能是负数。")
        if end_frame is not None and int(end_frame) < 0:
            raise MmdError("end_frame 不能是负数。")
        if fps is not None and int(fps) <= 0:
            raise MmdError("fps 需要是正数。")
        updates = {}
        if script_name is not None:
            updates["ScriptName"] = script_name
        if start_frame is not None:
            updates["StartFrame"] = str(int(start_frame))
        if end_frame is not None:
            updates["EndFrame"] = str(int(end_frame))
        if fps is not None:
            updates["ExportFPS"] = str(int(fps))
        if script_call is not None:
            updates["ScriptCallSetting"] = str(int(script_call))
        if not updates:
            raise MmdError("没有要写入的设置。")
        text = ini.read_text(encoding="utf-8", errors="replace")
        lines = text.splitlines()
        in_settings = False
        seen: set[str] = set()
        out: list[str] = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                if in_settings:
                    for key, value in updates.items():
                        if key not in seen:
                            out.append(f"{key}={value}")
                            seen.add(key)
                in_settings = stripped.lower() == "[settings]"
                out.append(line)
                continue
            if in_settings and "=" in line and not stripped.startswith(";"):
                key = line.split("=", 1)[0].strip()
                if key in updates:
                    out.append(f"{key}={updates[key]}")
                    seen.add(key)
                    continue
            out.append(line)
        if len(seen) != len(updates):
            if not in_settings:
                out.append("[Settings]")
            for key, value in updates.items():
                if key not in seen:
                    out.append(f"{key}={value}")
        ini.write_text("\n".join(out) + "\n", encoding="utf-8")
        running = any(row["edition"] == edition for row in self.instances())
        return {
            "ok": True,
            "ini": str(ini),
            "updated": updates,
            "restart_required": running,
            "note": "MMD 只在启动时读取这份 ini。窗口已经开着时，需要关掉再启动才会生效。" if running else "下次启动 MMD 会使用这些设置。",
        }

    def bridge_scene(self) -> dict:
        out = self.root / "out"
        files = {
            "start": out / "mmd_mcp_scene_start.json",
            "end": out / "mmd_mcp_scene_end.json",
            "error": out / "mmd_mcp_error.txt",
        }
        payload = {"ok": True, "out_dir": str(out)}
        for key, path in files.items():
            if not path.is_file():
                payload[key] = None
                continue
            if path.suffix == ".json":
                try:
                    payload[key] = json.loads(path.read_text(encoding="utf-8"))
                except (OSError, ValueError) as exc:
                    payload[key] = f"读不出来: {exc}"
            else:
                payload[key] = path.read_text(encoding="utf-8", errors="replace")[-4000:]
        if payload["start"] is None and payload["end"] is None:
            payload["note"] = "还没有快照。把 MMDBridge 脚本设为 mmd_mcp_observe.py 后导出一次 AVI，才会写出 out/mmd_mcp_scene_start.json。"
        return payload

    def list_files(self, directory: str | None, kind: str | None, limit: int = 200) -> dict:
        folder = Path(directory) if directory else self.root / "UserFile"
        if not folder.is_dir():
            raise MmdError(f"目录不存在: {folder}")
        if kind is not None and kind not in FILE_EXT:
            raise MmdError(f"未知的 kind {kind!r}，可选: {', '.join(FILE_EXT)}")
        allowed = FILE_EXT.get(kind) if kind else None
        rows = []
        for dirpath, dirnames, filenames in os.walk(folder):
            dirnames[:] = [name for name in dirnames if name not in {"Lib", "DLLs", "__pycache__"}]
            for name in filenames:
                if allowed and Path(name).suffix.lower() not in allowed:
                    continue
                rows.append(str(Path(dirpath) / name))
                if len(rows) >= limit:
                    return {"ok": True, "directory": str(folder), "truncated": True, "files": rows}
        return {"ok": True, "directory": str(folder), "truncated": False, "count": len(rows), "files": rows}

    def dismiss(self, edition: str | None, choice: str) -> dict:
        if choice not in CHOICE_IDS:
            raise MmdError(f"choice 只能是: {', '.join(CHOICE_IDS)}")
        with self._lock:
            inst = self.require(edition)
            log = []
            for dlg in self.dialogs(inst["pid"]):
                info = self._describe_dialog(dlg)
                if info["file_dialog"] and choice in {"cancel"}:
                    info["action"] = self._click_choice(dlg, "cancel")
                elif info["file_dialog"]:
                    info["action"] = "file-dialog-not-auto-filled"
                else:
                    info["action"] = self._click_choice(dlg, choice)
                log.append(info)
            return {"ok": True, "dialogs": log}

    def _ffmpeg(self) -> str | None:
        from shutil import which

        return which("ffmpeg")

    def _note(self, action: str, detail: dict) -> None:
        self.history.append({"action": action, "time": time.time(), **detail})
        self.history = self.history[-30:]

    def status(self) -> dict:
        return {
            "ok": True,
            "root": str(self.root),
            "port": int(os.environ.get("MMD_MCP_PORT", "9877")),
            "instances": self.instances(),
            "recent": self.history[-8:],
            "commands": COMMANDS,
            "motion": self._motion,
        }


def new_session_id() -> str:
    return uuid.uuid4().hex
