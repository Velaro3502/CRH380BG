"""Stress and edge case pass over the MMD MCP server.

Protocol layer: malformed requests, batches, unknown methods, bogus lengths.
Tool layer: out of range arguments, missing files, wrong types, concurrency.

A case fails when the server answers 5xx, hangs, dies, logs a traceback, or
leaks a raw Python exception to the client.
"""

import http.client
import json
import sys
import threading
import time
from pathlib import Path

HOST = "127.0.0.1"
PORT = 9877
LOG = Path(__file__).resolve().parent.parent / "mmd-mcp.log"

results = []
PYTHON_ERRORS = ("KeyError", "TypeError", "ValueError", "IndexError", "AttributeError", "Traceback", "OSError")


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    print(("PASS " if ok else "FAIL ") + name + (("  -> " + detail) if detail and not ok else ""))


def post(payload, timeout=60, raw=False):
    conn = http.client.HTTPConnection(HOST, PORT, timeout=timeout)
    try:
        body = payload if raw else json.dumps(payload, ensure_ascii=False)
        if isinstance(body, str):
            body = body.encode("utf-8")
        conn.request("POST", "/mcp", body=body, headers={"Content-Type": "application/json"})
        resp = conn.getresponse()
        return resp.status, resp.read().decode("utf-8", errors="replace")
    finally:
        conn.close()


def call(name, arguments, expect_error=False, timeout=90):
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments},
    }
    started = time.time()
    try:
        status, body = post(payload, timeout=timeout)
    except Exception as exc:  # noqa: BLE001
        record(name, False, f"transport error: {type(exc).__name__}: {exc}")
        return None
    took = time.time() - started
    if status != 200:
        record(name, False, f"http {status}: {body[:160]}")
        return None
    try:
        data = json.loads(body)
    except Exception as exc:  # noqa: BLE001
        record(name, False, f"not json: {exc}: {body[:160]}")
        return None
    if "error" in data:
        record(name, False, f"jsonrpc error: {data['error']}")
        return None
    result = data.get("result", {})
    text = result.get("content", [{}])[0].get("text", "")
    try:
        inner = json.loads(text)
    except Exception:  # noqa: BLE001
        record(name, False, f"content not json: {text[:160]}")
        return None
    is_error = bool(result.get("isError"))
    if expect_error:
        if not is_error:
            record(name, False, f"expected an error, got ok={inner.get('ok')}")
        else:
            msg = str(inner.get("error", ""))
            leaky = [token for token in PYTHON_ERRORS if token in msg]
            record(name, not leaky, ("leaky message: " + msg) if leaky else "")
        return inner
    if is_error:
        record(name, False, "unexpected error: " + str(inner.get("error"))[:200])
        return inner
    record(name, True, f"({took:.1f}s)")
    return inner


def traceback_count():
    try:
        return LOG.read_text(encoding="utf-8", errors="replace").count("Traceback")
    except OSError:
        return 0


before_tracebacks = traceback_count()
print(f"tracebacks in log before the run: {before_tracebacks}")

print("=== protocol layer ===")

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-06-18"}})
record("initialize 2025-06-18", status == 200 and "protocolVersion" in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "1999-01-01"}})
record("initialize unknown version", status == 200 and "protocolVersion" in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {}})
record("initialize without params", status == 200 and "protocolVersion" in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "ping"})
record("ping", status == 200 and '"result"' in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/list"})
record("tools/list", status == 200 and '"tools"' in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "no_such_tool", "arguments": {}}})
record("unknown tool", status == 200 and '"error"' in body, body[:120])

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {}})
record("tools/call without name", status == 200 and '"error"' in body)

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "mmd_status", "arguments": "not an object"}})
record("arguments not an object", status == 200 and '"error"' in body, body[:120])

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": "not an object"})
record("params not an object", status == 200 and '"error"' in body, body[:120])

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "no/such/method"})
record("unknown method", status == 200 and '"error"' in body)

status, body = post({"jsonrpc": "2.0", "method": "notifications/initialized"})
record("notification (no id)", status in (200, 202), f"status {status}")

status, body = post(
    [
        {"jsonrpc": "2.0", "id": 1, "method": "ping"},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
    ]
)
record("batch request", status == 200 and body.count('"id"') >= 2, f"status {status}")

status, body = post("{not json", raw=True)
record("malformed json", status == 400, f"status {status}")

status, body = post("", raw=True)
record("empty body", status in (200, 202, 400), f"status {status}")

status, body = post({"jsonrpc": "2.0", "id": 1, "method": "tools/call", "params": {"name": "mmd_status"}})
record("tools/call before initialize", status == 200)

try:
    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("GET", "/health")
    resp = conn.getresponse()
    body = resp.read().decode()
    record("GET /health", resp.status == 200 and '"ok":true' in body.replace(" ", ""))
    conn.close()

    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("GET", "/")
    resp = conn.getresponse()
    resp.read()
    record("GET /", resp.status == 200)
    conn.close()

    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("GET", "/nope")
    resp = conn.getresponse()
    resp.read()
    record("GET unknown path", resp.status == 405, f"status {resp.status}")
    conn.close()

    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("OPTIONS", "/mcp")
    resp = conn.getresponse()
    resp.read()
    record("OPTIONS /mcp", resp.status in (200, 204))
    conn.close()

    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("DELETE", "/mcp")
    resp = conn.getresponse()
    resp.read()
    record("DELETE /mcp", resp.status == 200)
    conn.close()

    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("POST", "/mcp", body=b"{}", headers={"Content-Type": "text/plain"})
    resp = conn.getresponse()
    resp.read()
    record("POST wrong content type", resp.status in (200, 202, 400), f"status {resp.status}")
    conn.close()

    started = time.time()
    conn = http.client.HTTPConnection(HOST, PORT, timeout=15)
    conn.request("POST", "/mcp", body=b"", headers={"Content-Length": "99999999"})
    resp = conn.getresponse()
    resp.read()
    took = time.time() - started
    record("POST bogus content length", resp.status == 413 and took < 5, f"status {resp.status} in {took:.1f}s")
    conn.close()
except Exception as exc:  # noqa: BLE001
    record("raw http checks", False, f"{type(exc).__name__}: {exc}")

print()
print("=== concurrency ===")

outcomes = []


def worker(index):
    try:
        status, body = post({"jsonrpc": "2.0", "id": index, "method": "tools/call", "params": {"name": "mmd_status", "arguments": {}}}, timeout=30)
        # The tool answer is a JSON string inside the JSON-RPC envelope.
        outcomes.append(status == 200 and "ok" in body and "error" not in body)
    except Exception:  # noqa: BLE001
        outcomes.append(False)


threads = [threading.Thread(target=worker, args=(i,)) for i in range(8)]
for thread in threads:
    thread.start()
for thread in threads:
    thread.join()
record("8 concurrent status calls", all(outcomes) and len(outcomes) == 8, f"{outcomes}")

print()
print("=== tool layer ===")

call("mmd_status", {})
call("mmd_menu", {}, timeout=90)
call("mmd_controls", {"class_name": "Edit", "limit": 5})
call("mmd_controls", {"class_name": "NoSuchClass"})
call("mmd_controls", {"text_contains": "Go"})
call("mmd_controls", {"limit": "abc"}, expect_error=True)
call("mmd_list_files", {"kind": "model", "limit": 5})
call("mmd_list_files", {"directory": r"Z:\definitely\not\here", "kind": "model"}, expect_error=True)
call("mmd_list_files", {"kind": "not_a_kind"}, expect_error=True)
call("mmd_bridge_scene", {})

call("mmd_set_frame", {"frame": -1}, expect_error=True)
call("mmd_set_frame", {"frame": 0})
call("mmd_set_frame", {"frame": 999999}, expect_error=True)
call("mmd_set_frame", {"frame": 99999})
call("mmd_set_frame", {"frame": 4777})
call("mmd_set_frame", {"frame": 4780})
call("mmd_set_frame", {"frame": "48"})
call("mmd_set_frame", {"frame": "abc"}, expect_error=True)
call("mmd_set_frame", {"frame": None}, expect_error=True)
call("mmd_set_frame", {}, expect_error=True)

call("mmd_set_resolution", {"width": 0, "height": 0}, expect_error=True)
call("mmd_set_resolution", {"width": -5, "height": 10}, expect_error=True)
call("mmd_set_resolution", {"width": 99999, "height": 10}, expect_error=True)
call("mmd_set_resolution", {"width": 1, "height": 1})
call("mmd_set_resolution", {"width": "640", "height": "480"})
call("mmd_set_resolution", {"width": "abc", "height": 480}, expect_error=True)
call("mmd_set_resolution", {"width": 640}, expect_error=True)

call("mmd_import_model", {"path": r"Z:\nope\missing.pmx"}, expect_error=True)
call("mmd_import_model", {"path": r"G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64\UserFile"}, expect_error=True)
call("mmd_import_model", {"path": r"G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64\readme_mmdbridge.md"}, expect_error=True)
call("mmd_import_motion", {"path": r"Z:\nope\missing.vmd"}, expect_error=True)
call("mmd_import_pose", {"path": r"Z:\nope\missing.vpd"}, expect_error=True)
call("mmd_import_audio", {"path": r"Z:\nope\missing.wav"}, expect_error=True)
call("mmd_import_accessory", {"path": r"Z:\nope\missing.x"}, expect_error=True)
call("mmd_import_model", {"path": 12345}, expect_error=True)
call("mmd_import_model", {}, expect_error=True)

call("mmd_export_image", {"path": r"Z:\nowhere\out.bmp"}, expect_error=True)
call("mmd_export_image", {"path": r"G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64\UserFile"}, expect_error=True)
call("mmd_export_image", {"path": r"G:\MMDBridge_v1.3.0\MikuMikuDance_v932x64\UserFile\Model"}, expect_error=True)
call("mmd_screenshot", {"path": r"Z:\nowhere\shot.png"}, expect_error=True)

call("mmd_export_video", {"method": "screen", "path": r"Z:\nowhere\a.mp4"}, expect_error=True)
call("mmd_export_video", {"method": "screen", "path": r"Z:\nowhere\a.mp4", "end_frame": 301}, expect_error=True)
call("mmd_export_video", {"method": "screen", "path": r"Z:\nowhere\a.mp4", "end_frame": -5}, expect_error=True)
call("mmd_export_video", {"method": "screen", "path": r"Z:\nowhere\a.mp4", "end_frame": "abc"}, expect_error=True)
call("mmd_export_video", {"method": "avi", "path": r"Z:\nowhere\a.avi"}, expect_error=True)
call("mmd_export_video", {"method": "nope", "path": r"Z:\nowhere\a.avi"}, expect_error=True)

call("mmd_invoke", {"name": "no_such_command"}, expect_error=True)
call("mmd_invoke", {"menu_path": ["不存在", "也没有"]}, expect_error=True)
call("mmd_invoke", {}, expect_error=True)
call("mmd_invoke", {"command_id": "abc"}, expect_error=True)
call("mmd_set_control_text", {"hwnd": 999999, "text": "x"}, expect_error=True)
call("mmd_set_control_text", {"control_id": 999999, "text": "x"}, expect_error=True)
call("mmd_set_control_text", {"control_id": "abc", "text": "x"}, expect_error=True)
call("mmd_dismiss_dialogs", {"choice": "ok"})
call("mmd_dismiss_dialogs", {"choice": "nope"}, expect_error=True)
call("mmd_close", {"edition": "nope"}, expect_error=True)
call("mmd_launch", {"edition": "nope"}, expect_error=True)
call("mmd_configure_bridge", {"edition": "nope", "fps": 30}, expect_error=True)
call("mmd_configure_bridge", {}, expect_error=True)
call("mmd_configure_bridge", {"fps": "abc"}, expect_error=True)

print()
print("=== server health ===")

try:
    conn = http.client.HTTPConnection(HOST, PORT, timeout=10)
    conn.request("GET", "/health")
    resp = conn.getresponse()
    body = resp.read().decode()
    record("server still healthy", resp.status == 200 and '"ok":true' in body.replace(" ", ""))
    conn.close()
except Exception as exc:  # noqa: BLE001
    record("server still healthy", False, f"{type(exc).__name__}: {exc}")

after_tracebacks = traceback_count()
record(
    "no new traceback logged",
    after_tracebacks == before_tracebacks,
    f"{after_tracebacks - before_tracebacks} new traceback(s)",
)

failed = [row for row in results if not row[1]]
print()
print(f"{len(results) - len(failed)}/{len(results)} passed")
for name, _ok, detail in failed:
    print(f"  FAIL {name}: {detail}")
sys.exit(1 if failed else 0)
