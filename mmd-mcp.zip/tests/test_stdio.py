"""Exercise the stdio transport of the MCP server.

The README documents `python server.py --stdio` as an alternative to the HTTP
port, so that path needs its own check: framing, several messages in one
session, and a clean exit at EOF.
"""

import json
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SERVER = str(ROOT / "server.py")
PYTHON = sys.executable

proc = subprocess.Popen(
    [PYTHON, "-u", SERVER, "--stdio"],
    stdin=subprocess.PIPE,
    stdout=subprocess.PIPE,
    stderr=subprocess.PIPE,
    cwd=str(ROOT),
)

failures = []


def send(payload):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    proc.stdin.write(f"Content-Length: {len(body)}\r\n\r\n".encode("ascii") + body)
    proc.stdin.flush()


def read_message(timeout=30):
    """Read one Content-Length framed message."""
    deadline = time.time() + timeout
    headers = {}
    while True:
        line = proc.stdout.readline()
        if not line:
            raise TimeoutError("no headers")
        if line in (b"\r\n", b"\n"):
            break
        key, value = line.decode("ascii").split(":", 1)
        headers[key.strip().lower()] = value.strip()
        if time.time() > deadline:
            raise TimeoutError("header read timeout")
    length = int(headers.get("content-length", "0"))
    data = proc.stdout.read(length)
    if time.time() > deadline:
        raise TimeoutError("body read timeout")
    return json.loads(data.decode("utf-8"))


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (("  -> " + detail) if detail and not ok else ""))
    if not ok:
        failures.append(name)


try:
    send({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2025-03-26"}})
    answer = read_message()
    check("stdio initialize", "protocolVersion" in answer.get("result", {}))

    send({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    answer = read_message()
    tools = answer.get("result", {}).get("tools", [])
    check("stdio tools/list", len(tools) >= 20, f"{len(tools)} tools")

    send({"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "mmd_status", "arguments": {}}})
    answer = read_message()
    text = answer.get("result", {}).get("content", [{}])[0].get("text", "")
    check("stdio mmd_status", '"ok": true' in text or '"ok":true' in text, text[:120])

    send({"jsonrpc": "2.0", "id": 4, "method": "tools/call", "params": {"name": "no_such_tool", "arguments": {}}})
    answer = read_message()
    check("stdio unknown tool", "error" in answer, str(answer)[:120])

    # a notification carries no id and must not produce an answer
    send({"jsonrpc": "2.0", "method": "notifications/initialized"})
    send({"jsonrpc": "2.0", "id": 5, "method": "ping"})
    answer = read_message()
    check("stdio notification then ping", answer.get("id") == 5, str(answer)[:120])
except Exception as exc:  # noqa: BLE001
    check("stdio session", False, f"{type(exc).__name__}: {exc}")
finally:
    try:
        proc.stdin.close()
    except Exception:  # noqa: BLE001
        pass
    try:
        proc.wait(timeout=15)
    except Exception:  # noqa: BLE001
        proc.kill()
    check("stdio exits at EOF", proc.returncode is not None, f"returncode={proc.returncode}")

print(f"{'all good' if not failures else str(len(failures)) + ' failure(s)'}")
sys.exit(1 if failures else 0)
