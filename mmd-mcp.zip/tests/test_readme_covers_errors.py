"""Check that every message the server can send is explained in the README.

Run it after changing any error text or the README:

    python tests\\test_readme_covers_errors.py

Messages whose own wording already tells the user what to do are listed in
SELF_EXPLANATORY. Everything else needs a phrase in the README.
"""

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
README = (ROOT / "README.md").read_text(encoding="utf-8")

# Distinctive fragment of the message -> phrase that has to be in the README.
COVERAGE = {
    "MMD 没有在运行": "MMD 没有在运行",
    "开着多个 MMD": "开着多个 MMD",
    "找不到 ": "找不到 xxx.exe",
    "已启动，但": "没有出现主窗口",
    "MMD 的帧号上限是": "99999",
    "帧号不能是负数": "99999",
    "分辨率超出可接受范围": "99999",
    "帧号框写入失败": "帧号框写入失败",
    "有对话框开着": "有对话框开着",
    "没有找到时间轴上的 Go 按钮": "mmd_set_frame",
    "Go 按钮左边没有帧号输入框": "mmd_set_frame",
    "已经存在": "overwrite=true",
    "无法创建目录": "无法创建目录",
    "无法覆盖": "无法覆盖",
    "是一个目录": "不是文件路径",
    "路径 ": "不是文件路径",
    "屏幕录像的 end_frame": "0 到 300 之间",
    "等待 AVI 写完超时": "等待 AVI 写完超时",
    "跳到第": "跳到第",
    "没能把当前帧设到导出终点": "没能把当前帧设到导出终点",
    "没能设置导出分辨率": "没能设置导出分辨率",
    "录像过程中窗口尺寸变了": "录像过程中窗口尺寸变了",
    "没有出现分辨率设定窗口": "没有出现分辨率设定窗口",
    "分辨率窗口里没有宽和高": "分辨率窗口里没有宽和高",
    "主窗口没有菜单": "主窗口没有菜单",
    "窗口尺寸无效": "窗口尺寸无效",
    "读取画面像素失败": "读取画面像素失败",
    "截取窗口失败": "截取窗口失败",
    "GlobalAlloc 失败": "GlobalAlloc 失败",
    "投递文件失败": "投递文件失败",
    "PostMessage 命令": "PostMessage 命令",
    "需要这些扩展名": "需要这些扩展名",
    "文件不存在": "文件不存在",
    "目录不存在": "目录不存在",
    "未知版本": "未知版本",
    "未知的 kind": "未知的 kind",
    "未知命令名": "未知命令名",
    "这一层有": "menu_path",
    "这个菜单项还会展开": "menu_path",
    "choice 只能是": "choice",
    "on_prompt 只能是": "on_prompt",
    "script_call 只能是": "script_call",
    "start_frame 不能是负数": "start_frame",
    "end_frame 不能是负数": "end_frame",
    "fps 需要是正数": "fps",
    "control_id=": "control_id",
    "需要 hwnd 或 control_id": "需要 hwnd 或 control_id",
    "需要 name、command_id 或 menu_path": "name",
    "参数 ": "需要是整数",
    "缺少参数": "缺少参数",
    "缺少路径参数": "缺少路径参数",
    "params 必须是对象": "params",
    "arguments 必须是对象": "arguments",
    "没有这个工具": "没有这个工具",
    "不支持的方法": "不支持的方法",
    "内部错误": "内部错误",
    "request body too large": "request body too large",
    "导出的帧范围": "导出范围必须和 ini 里的烘焙范围一致",
    "动作是在第": "偏移量等于导入时所在的帧",
}

# Messages that speak for themselves, so the README does not need to repeat them.
SELF_EXPLANATORY = {
    "没有要写入的设置。",
    "目录不存在: {folder}",
}


def collect():
    messages = []
    for name in ("server.py", "mmd_control.py"):
        text = (ROOT / name).read_text(encoding="utf-8")
        for pattern in (r'raise MmdError\(\s*f?"([^"]*)"', r'"error":\s*f?"([^"]*)"'):
            for match in re.finditer(pattern, text):
                messages.append((name, match.group(1)))
        for match in re.finditer(r'warnings\.append\(\s*f?"([^"]*)"', text):
            messages.append((name, match.group(1)))
        for match in re.finditer(r'"reason":\s*f?"([^"]*)"', text):
            messages.append((name, match.group(1)))
    return sorted(set(messages))


def main():
    failures = []
    for name, message in collect():
        if message in SELF_EXPLANATORY or not message.strip():
            continue
        for token, phrase in COVERAGE.items():
            if token in message:
                if phrase not in README:
                    failures.append(f"{name}: {message!r} -> README 里没有 {phrase!r}")
                break
        else:
            failures.append(f"{name}: {message!r} -> COVERAGE 表里没有对应条目")

    print(f"检查了 {len(collect())} 条消息")
    if failures:
        print(f"{len(failures)} 条没被 README 覆盖：")
        for row in failures:
            print("  ", row)
        return 1
    print("全部覆盖")
    return 0


if __name__ == "__main__":
    sys.exit(main())
