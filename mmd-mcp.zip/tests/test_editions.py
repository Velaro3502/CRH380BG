"""Edition handling: no MMD running, and the other language builds.

The server claims to drive CHS, CHT, console and the original Japanese build.
Every one of them has to be found, driven and closed cleanly.
"""

import json
import sys
import time
import urllib.error
import urllib.request

URL = "http://127.0.0.1:9877/mcp"
failures = []


def call(name, arguments=None, timeout=120):
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "tools/call",
        "params": {"name": name, "arguments": arguments or {}},
    }
    request = urllib.request.Request(
        URL, data=json.dumps(payload, ensure_ascii=False).encode("utf-8"), headers={"Content-Type": "application/json"}
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        return {"transport_error": f"{type(exc).__name__}: {exc}"}
    if "error" in body:
        return {"rpc_error": body["error"]}
    result = body.get("result", {})
    text = result.get("content", [{}])[0].get("text", "")
    try:
        return json.loads(text)
    except Exception:  # noqa: BLE001
        return {"raw": text}


def check(name, ok, detail=""):
    print(("PASS " if ok else "FAIL ") + name + (("  -> " + detail) if detail and not ok else ""))
    if not ok:
        failures.append(name)


print("=== no MMD running ===")
call("mmd_close", {"edition": "chs", "on_prompt": "discard"})
time.sleep(1.0)

status = call("mmd_status")
check("status without MMD", status.get("ok") is True and status.get("instances") == [], str(status)[:160])

result = call("mmd_set_frame", {"frame": 10})
check("set_frame without MMD", result.get("isError") or result.get("error"), str(result)[:160])

result = call("mmd_launch", {"edition": "nope"})
check("launch unknown edition", result.get("isError") or result.get("error"), str(result)[:160])

print()
print("=== CHT (traditional Chinese) ===")
result = call("mmd_launch", {"edition": "cht"}, timeout=60)
check("launch cht", result.get("ok") is True and result.get("edition") == "cht", str(result)[:200])

status = call("mmd_status")
editions = [row["edition"] for row in status.get("instances", [])]
check("cht shows up in status", "cht" in editions, str(editions))

result = call("mmd_set_frame", {"frame": 24, "edition": "cht"})
check("cht set_frame", result.get("ok") is True, str(result)[:200])

result = call("mmd_screenshot", {"edition": "cht", "path": r"G:\MMDBridge_v1.3.0\mmd-mcp\shots\cht_test.png"})
check("cht screenshot", result.get("ok") is True, str(result)[:200])

result = call("mmd_menu", {"edition": "cht"}, timeout=90)
check("cht menu", result.get("ok") is True and isinstance(result.get("menu"), list), str(result)[:160])

result = call("mmd_close", {"edition": "cht", "on_prompt": "discard"}, timeout=60)
check("close cht", result.get("ok") is True and result.get("still_open") is False, str(result)[:200])

print()
print("=== original (Japanese) ===")
result = call("mmd_launch", {"edition": "original"}, timeout=60)
check("launch original", result.get("ok") is True and result.get("edition") == "original", str(result)[:200])

result = call("mmd_set_frame", {"frame": 12, "edition": "original"})
check("original set_frame", result.get("ok") is True, str(result)[:200])

result = call("mmd_close", {"edition": "original", "on_prompt": "discard"}, timeout=60)
check("close original", result.get("ok") is True and result.get("still_open") is False, str(result)[:200])

print()
print("=== console build ===")
result = call("mmd_launch", {"edition": "console"}, timeout=60)
check("launch console", result.get("ok") is True and result.get("edition") == "console", str(result)[:200])

result = call("mmd_close", {"edition": "console", "on_prompt": "discard"}, timeout=60)
check("close console", result.get("ok") is True and result.get("still_open") is False, str(result)[:200])

print()
print("=== back to CHS ===")
result = call("mmd_launch", {"edition": "chs"}, timeout=60)
check("launch chs again", result.get("ok") is True and result.get("edition") == "chs", str(result)[:200])

status = call("mmd_status")
check("exactly one instance", len(status.get("instances", [])) == 1, str(status.get("instances"))[:200])

print()
print(f"{'all good' if not failures else str(len(failures)) + ' failure(s)'}")
sys.exit(1 if failures else 0)
